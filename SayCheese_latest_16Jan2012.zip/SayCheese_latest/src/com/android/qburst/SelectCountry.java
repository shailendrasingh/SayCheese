package com.android.qburst;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class SelectCountry extends Activity {

	/** list with countries.*/
	private ListView listViewSelectCountry;
	private EditText txtSearchCountry;
	private Context context = this;
	private ArrayAdapter<String> countryAdapter;
	private OnItemClickListener coutryListener = new OnItemClickListener() {
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			String country = (String) arg0.getItemAtPosition(arg2);
			Intent countryResult = new Intent();
			countryResult.putExtra("country", country);
			setResult(RESULT_OK, countryResult);
			finish();	
		}
	};
	private TextWatcher textWatcher = new TextWatcher() {
		
		public void onTextChanged(CharSequence s, int start, int before, int count) {
			countryAdapter.getFilter().filter(s);
		}
		
		public void beforeTextChanged(CharSequence s, int start, int count,	int after) { }
		
		public void afterTextChanged(Editable s) { }
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select_country);		
		Resources res = getResources();
		String [] countries = res.getStringArray(R.array.countries_array);
		countryAdapter = new ArrayAdapter<String>(context, R.layout.country_item, R.id.countryItemName, countries);
		
		listViewSelectCountry = (ListView) findViewById(R.id.countryList);
		listViewSelectCountry.setTextFilterEnabled(true);
		listViewSelectCountry.setAdapter(countryAdapter);
		listViewSelectCountry.setOnItemClickListener(coutryListener);
		
		txtSearchCountry = (EditText) findViewById(R.id.txtSearchCountry);
		txtSearchCountry.addTextChangedListener(textWatcher);
	}
}
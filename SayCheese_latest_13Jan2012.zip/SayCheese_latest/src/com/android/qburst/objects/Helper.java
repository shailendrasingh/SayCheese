package com.android.qburst.objects;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.android.qburst.textedition.TextEditionConstants;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

final public class Helper {
	
	final static String fontNotFoundMsg = "Font not found, default one chosen"; 
	final static String sdCardNotFoundMsg = "No external storage available!"; 
	final static String DATE_FORMAT_NOW = "yyyy-MM-dd 'at' HH:mm:ss";
	private static SimpleDateFormat sdf = null;
	private static String date = null;
	public static Typeface getFont(String fontName, Context context){
		Typeface font = Typeface.SERIF;
		try {
			if (fontName.equals(TextEditionConstants.typefaceSerif)) {
				font = Typeface.SERIF;
			} else if (fontName.equalsIgnoreCase(TextEditionConstants.typefaceSan)) {
				font = Typeface.SANS_SERIF;
			} else if (fontName.equalsIgnoreCase(TextEditionConstants.typefaceMono)) {
				font = Typeface.MONOSPACE;
			} else {
				font = Typeface.createFromAsset(context.getAssets(), "fonts/" + fontName+".ttf");
			}
		} catch (Exception e) {
			Log.e("getFont()", ""+e.getMessage());
			Toast.makeText(context, fontNotFoundMsg, Toast.LENGTH_LONG).show();
		}
		return font;
	}
	
	public static String nowDate() {
		if(sdf == null){
			sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
			date = sdf.format(new Date());
		}
		return date;
	}
	
	public static String saveImageInExternalCacheDir(Context context, Bitmap bitmap, String myfileName){
		String fileName = myfileName + nowDate().toString().replace(' ', '_').replace(":", "_");
		String filePath = null;
		try{
//			String filePath = context.getCacheDir().getPath() + "/" + fileName;
			filePath = (context.getExternalCacheDir()).toString() + "/" + fileName;
			try {
				FileOutputStream fos = new FileOutputStream(new File(filePath));
				bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos);
				fos.flush();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}catch (Exception e) {
			Toast.makeText(context, sdCardNotFoundMsg, Toast.LENGTH_LONG).show();
		}
		return filePath;
	}
	
	public static Bitmap readImageFromSpecifiedDir(Context context, String filepath){
		BitmapFactory.Options bfo = new BitmapFactory.Options();
		Uri ufileName = Uri.fromFile(new File(filepath));
		Bitmap background = null;
        try {
        	background = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(ufileName), null, bfo);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
        return background;
	}
	
	public static String getRealPathFromURI(Activity activity, Uri contentUri) {
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = activity.managedQuery(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
	
	public static Bitmap readImageFromAssets(Context mContext, String folderName, String imageName){
		InputStream buffer = null;
		try {
			buffer = new BufferedInputStream((mContext.getAssets().open(folderName + imageName + ".jpg")));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return BitmapFactory.decodeStream(buffer);
	}
	
	public static String readInputStreamAsString(InputStream in) throws IOException {
	    BufferedInputStream bis = new BufferedInputStream(in);
	    ByteArrayOutputStream buf = new ByteArrayOutputStream();
	    int result = bis.read();
	    while(result != -1) {
	      byte b = (byte)result;
	      buf.write(b);
	      result = bis.read();
	    }        
	    return buf.toString();
	}
	
	public static int convertFromDPtoInt(Activity activity, int valuInDP) throws IOException {
	    DisplayMetrics metrics = new DisplayMetrics();
	    activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
	    float logicalDensity = metrics.density;
	    return (int) (valuInDP * logicalDensity + 0.5);
	}
	
	public static Bitmap createSnapShot(View cardView){
	   int width = cardView.getWidth();
       int height = cardView.getHeight();
       int left = cardView.getLeft();
       int top = cardView.getTop();
       Bitmap mBitmap = Bitmap.createBitmap( width, height, Bitmap.Config.ARGB_8888);                
       Canvas c = new Canvas(mBitmap);
       cardView.layout(0, 0, width, height);
       cardView.draw(c);
       cardView.layout(left, top, width+left, height+top);
       return mBitmap;
	}
}

package com.android.qburst;
import android.graphics.Camera;
import android.graphics.Matrix;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Transformation;
import android.widget.LinearLayout;

public class Flip3dAnimation  extends Animation {
	private final float mFromDegrees;
	private final float mToDegrees;
	private final float mCenterX;
	private final float mCenterY;
	private Camera mCamera;

	public Flip3dAnimation(float fromDegrees, float toDegrees, float centerX, float centerY) {
		mFromDegrees = fromDegrees;
		mToDegrees = toDegrees;
		mCenterX = centerX;
		mCenterY = centerY;
	}
	public DisplayNextView createDisplayNexView (boolean isFirstImage, LinearLayout image1, LinearLayout image2)
	{
		return new DisplayNextView(isFirstImage,image1, image2);
	}
	
	@Override
	public void initialize(int width, int height, int parentWidth, int parentHeight) {
		super.initialize(width, height, parentWidth, parentHeight);
		mCamera = new Camera();
	}
	
	@Override
	protected void applyTransformation(float interpolatedTime, Transformation t) {
		final float fromDegrees = mFromDegrees;
		float degrees = fromDegrees + ((mToDegrees - fromDegrees) * interpolatedTime);
		
		final float centerX = mCenterX;
		final float centerY = mCenterY;
		final Camera camera = mCamera;
		
		final Matrix matrix = t.getMatrix();	
		camera.save();	
		camera.rotateY(degrees);
		camera.getMatrix(matrix);
		camera.restore();
	
		matrix.preTranslate(-centerX, -centerY);
		matrix.postTranslate(centerX, centerY);

	}
		public final class DisplayNextView implements Animation.AnimationListener {
			private boolean mCurrentView;
			LinearLayout image1;
			LinearLayout image2;
	
			public DisplayNextView(boolean currentView, LinearLayout image12, LinearLayout image22) {
				mCurrentView = currentView;
				this.image1 = image12;
				this.image2 = image22;
			}
	
			public void onAnimationStart(Animation animation) {
			}
	
			public void onAnimationEnd(Animation animation) {
				image1.post(new SwapViews(mCurrentView, image1, image2));
			}
	
			public void onAnimationRepeat(Animation animation) {
			}
			
			public final class SwapViews implements Runnable {
				private boolean mIsFirstView;
				LinearLayout image1;
				LinearLayout image2;
	
			public SwapViews(boolean isFirstView, LinearLayout image12, LinearLayout image22) {
				 mIsFirstView = isFirstView;
				 this.image1 = image12;
				 this.image2 = image22;
			}
	
			public void run() {
				 final float centerX = image1.getWidth() / 2.0f;
				 final float centerY = image1.getHeight() / 2.0f;
				 Flip3dAnimation rotation;
	
				 if (mIsFirstView) {
				  image1.setVisibility(View.GONE);
				  image2.setVisibility(View.VISIBLE);
				  image2.requestFocus();
		
				     rotation = new Flip3dAnimation(90, 0, centerX, centerY);
				 } else {
				  image2.setVisibility(View.GONE);
				  image1.setVisibility(View.VISIBLE);
				  image1.requestFocus();
	
				     rotation = new Flip3dAnimation(-90, 0, centerX, centerY);
				 }
		
				 rotation.setDuration(500);
				 rotation.setFillAfter(true);
				 rotation.setInterpolator(new DecelerateInterpolator());
	
				 if (mIsFirstView) {
					 image2.startAnimation(rotation);
				 } else {
					 image1.startAnimation(rotation);
				 }
			}
		}
	}
}
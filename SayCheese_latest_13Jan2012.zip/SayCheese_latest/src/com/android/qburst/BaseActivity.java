package com.android.qburst;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import com.android.qburst.facebook.DialogError;
import com.android.qburst.facebook.Facebook;
import com.android.qburst.facebook.FacebookError;
import com.android.qburst.facebook.FacebookGalleryList;
import com.android.qburst.facebook.SessionEvents;
import com.android.qburst.facebook.SessionStore;
import com.android.qburst.facebook.Utility;
import com.android.qburst.facebook.Facebook.DialogListener;
import com.flurry.android.FlurryAgent;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.provider.ContactsContract;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class BaseActivity extends Activity implements Callback {
	
	private static final int PICK_CONTACT = 0;
	protected static final int SHOW_DIALOG = 0;
	Handler handler=new Handler(this);


	public void onStart(){
	   super.onStart();
	   //pass context and application key for flurry analytics
	   FlurryAgent.onStartSession(this, "Q5WZMM2HFJSARFAT3SWC");
	   FlurryAgent.setUseHttps(true);
	}
	
	public void onStop(){
	   super.onStop();
	   // for flurry analytics
	   FlurryAgent.onEndSession(this);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
		return true;	
	}
	

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.menu_saved_cards:
            startActivity(new Intent(getApplicationContext(), SavedCards.class));
			break;
		case R.id.menu_help:
			startActivity(new Intent(getApplicationContext(), Help.class));
			break;
		case R.id.menu_refer:
			Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
			startActivityForResult(intent, BaseActivity.PICK_CONTACT);
			break;
		case R.id.menu_share:
	       	Utility.mFacebook = new Facebook(FacebookGalleryList.APP_ID);
	        SessionStore.restore(Utility.mFacebook, this);
	       	if(Utility.mFacebook.isSessionValid()) {
	            PublisherTask publisher=new PublisherTask();
	            publisher.execute();
	       	} else {
	       		Utility.mFacebook.authorize(this, FacebookGalleryList.permissions,Facebook.FORCE_DIALOG_AUTH /*AUTHORIZE_ACTIVITY_RESULT_CODE*/, new LoginDialogListener());
	       	}			
			break;
		default :
    		break;  	
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		switch (requestCode){
			case BaseActivity.PICK_CONTACT:
				if (resultCode==RESULT_OK){
					String id="none";
					String name = "none";
					String email="none";
					
					Uri contactData = data.getData();
			        Cursor c =  managedQuery(contactData, null, null, null, null);
			        if (c.moveToFirst()) {
			          name = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
			          id = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
			        }
			        c.close();
			        Cursor emailCur = getContentResolver().query( 
			        		ContactsContract.CommonDataKinds.Email.CONTENT_URI,	null,
			        		ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?", 
			        		new String[]{id}, null); 
		        	while (emailCur.moveToNext()) { 
		        	    email = emailCur.getString(emailCur.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
		         	    String emailType = emailCur.getString(emailCur.getColumnIndex(ContactsContract.CommonDataKinds.Email.TYPE));
		         	    break;
		         	}
		        	emailCur.close();
		            email(this,email,"","SayCheese","SayCheese is cool. Try it Yourself.",null);
				}
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	private void email(Context context, String emailTo, String emailCC, String subject, String emailText, ArrayList<Uri> filePaths) {
		    //need to "send multiple" to get more than one attachment
		    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		    emailIntent.setType("text/plain");
		    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{emailTo});
		    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, new String(subject));
		    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, new String(emailText));
		    if (emailCC.length()>0)
		    	emailIntent.putExtra(android.content.Intent.EXTRA_CC, new String[]{emailCC});
		    if (filePaths!=null)
		    	emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, filePaths);
		    context.startActivity(emailIntent);
	}
	
	private final class LoginDialogListener implements DialogListener {
        public void onComplete(Bundle values) {
            SessionEvents.onLoginSuccess();
            SessionStore.save(Utility.mFacebook, BaseActivity.this);
            PublisherTask publisher=new PublisherTask();
            publisher.execute();
            //postOnWall("You can now send cards through Say-Cheese", "");
        }

        public void onFacebookError(FacebookError error) {
            SessionEvents.onLoginError(error.getMessage());
        }
        
        public void onError(DialogError error) {
            SessionEvents.onLoginError(error.getMessage());
        }

        public void onCancel() {
            SessionEvents.onLoginError("Action Canceled");
        }
    }
	
	private class PublisherTask extends  AsyncTask<Void, Void, String>{
		ProgressDialog pd=null;
		AlertDialog ad=null;
		
		@Override
		protected void onPreExecute() {
			ad=new AlertDialog.Builder(BaseActivity.this).create();
			Message msgOk=new Message();
			msgOk.setTarget(handler);
			ad.setButton("OK", msgOk);
			pd=ProgressDialog.show(BaseActivity.this, "Say-Cheese", "Publishing on FB...");
			
		};
		
		@Override
		protected String doInBackground(Void... params) {
			Bundle parameters = new Bundle();
			
			parameters.putString("link", "goo.gl/XIHIA");
			parameters.putString("picture", "http://fbrell.com/f8.jpg");
			parameters.putString("name", "Say Cheese is cool");
			parameters.putString("caption", "http://www.say-cheese.com");
			parameters.putString("message","This app is cool, will allow u to design and send card from Android phones.");
			parameters.putString("description", "Say-Cheese is an online Photo application for creating your very own Photobooks, Photocalenders and Personal greeting and invite cards.\nSay-Cheese is an online solution developed by DataPost Pte. Ltd. a subsidiary of Singapore Post Ltd.");
			parameters.putString("redirect_uri", "");
			
			String response="Posted on Facebook wall";
			try {
				response = Utility.mFacebook.request("me/feed", parameters,"POST");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				response = e.getMessage();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				response = e.getMessage();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				response = e.getMessage();
			}
			return response;
		}
		
		@Override
		protected void onPostExecute(String result) {
			pd.dismiss();
			if (result == null || result.equals("") || result.equals("false")) {
				ad.setMessage("Error occoured: "+result);
				ad.setIcon(android.R.drawable.ic_dialog_alert);
            }else{
				ad.setMessage(result);
            }
			ad.show();
		};
		
	};
	
	public boolean handleMessage(Message msg) {
		// TODO Auto-generated method stub
		return false;
	}
}

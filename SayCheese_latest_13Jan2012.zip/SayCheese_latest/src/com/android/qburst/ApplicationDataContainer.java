package com.android.qburst;

import com.android.qburst.objects.AddressDetails;
import com.android.qburst.objects.Helper;
import com.android.qburst.objects.PostCard;
import com.android.qburst.objects.TextDetails;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.text.Html;


public class ApplicationDataContainer extends Application {
	
	private static AddressDetails cardSender;
	private static AddressDetails cardRecipient;
	private static TextDetails frontTitleText;
	private static TextDetails frontDescText;
	private static TextDetails backText;
	private static PostCard postCardDetails;
	private static Bitmap cardFrontImage;
	
	
	@Override
	public void onCreate() {
		setTexts();	
		setAddresDetails();
		cardFrontImage = null;
		makeFreshPostcard();
		
	}
	public void makeFreshPostcard(){
		postCardDetails = new PostCard(-1, PostCard.STATUS_CREATED, "", "", Helper.nowDate(),
				"", "cny1", "", "", 1.50575f, 0f, 0f);

	}
	public void setTexts() {
		/** set first front title text.
		 * position field values 1 - front top, 2 - front bottom, 3 - back top, 4 - back bottom */
		frontTitleText = new TextDetails(Html.fromHtml("<b>Gong Xi Fa Chai!</b>"),
				"SANS_SERIF", 13, 13, Color.argb(255, 0, 0, 0), 1, null);
		frontDescText = new TextDetails(Html.fromHtml("May you be happy and prosperous! Good fortunes as you wish!"),
				"SANS_SERIF", 12, 12, Color.argb(255, 0, 0, 0), 2, null);
		backText = new TextDetails(Html.fromHtml("May you be happy and prosperous! Good fortunes as you wish!"),
				"SANS_SERIF", 12, 12, Color.argb(255, 0, 0, 0) ,3, null);
	}

	private void setAddresDetails(){
		//address.type field values 1 - receiver, 2 - sender
		cardRecipient = new AddressDetails(1);
		cardSender = new AddressDetails(2);
	}

	public AddressDetails getCardSender() {
		return cardSender;
	}

	public void setCardSender(AddressDetails cardSender) {
		ApplicationDataContainer.cardSender = cardSender;
	}

	public AddressDetails getCardRecipient() {
		return cardRecipient;
	}

	public void setCardRecipient(AddressDetails cardRecipient) {
		ApplicationDataContainer.cardRecipient = cardRecipient;
	}

	public TextDetails getFrontTitleText() {
		return frontTitleText;
	}

	public void setFrontTitleText(TextDetails frontTitleText) {
		ApplicationDataContainer.frontTitleText = frontTitleText;
	}

	public TextDetails getFrontDescText() {
		return frontDescText;
	}

	public void setFrontDescText(TextDetails frontDescText) {
		ApplicationDataContainer.frontDescText = frontDescText;
	}

	public TextDetails getBackText() {
		return backText;
	}

	public void setBackText(TextDetails backText) {
		ApplicationDataContainer.backText = backText;
	}
	
	public Bitmap getCardFrontImage() {
		return cardFrontImage;
	}

	public void setCardFrontImage(Bitmap cardFrontImage) {
		ApplicationDataContainer.cardFrontImage = cardFrontImage;
	}

	public PostCard getPostCardDetails() {
		return postCardDetails;
	}

	public void setPostCardDetails(PostCard postCardDetails) {
		ApplicationDataContainer.postCardDetails = postCardDetails;
	}	
}

package com.android.qburst.objects;

public class Interfaces {

	public interface IZipCodeListener{
		public void handleExceptionWithNetwok();
		public void fillPostCodeData(AddressFromZip address);
	}
}

package com.android.qburst.objects;

public class AddressDetails {
	
	public final static int TYPE_RECEIVER = 1;
	public final static int TYPE_SENDER = 2;
	
	
	//address.type field values 1 - receiver, 2 - sender
	private int type = 0;
	private String fullName = "" ;
	private String state = "";
	private String address1 = "";
	private String address2 = "";
	private String city = "";

	private String zipCode = "";
	private String country = "";
	private String email = "";
	
	public AddressDetails(int mType, String mName, String mState, 
			String mAddress1, String mAddress2, String mCity, String mZipCode, String mCountry, String mEmail){
		
		type = mType;
		fullName = mName;
		state = mState;
		setAddress1(mAddress1);
		address2 = mAddress2;
		city = mCity;
		zipCode = mZipCode;
		country = mCountry;
		email = mEmail;
	}
	public AddressDetails(int mType){
		type = mType;
	}
	
	public int getType() {
		return type;
	}
	
	public void setType(int type) {
		this.type = type;
	}
	
	public void setFullName(String Name) {
		this.fullName = Name;
	}
	
	public String getFullName() {
		return fullName;
	}
	
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public boolean checkIfAllDataIsProvidedForSender (){
		boolean flag = false;
		if(address1.length() > 1 && email.length() > 1 && fullName.length() > 1
				&& city.length() > 1 && country.length() > 1){
				flag = true;
		}
		return flag;
	}
	
	public boolean checkIfAllDataIsProvidedForRecepient (){
		boolean flag = false;
		if(address1.length() > 1 && fullName.length() > 1
				&& city.length() > 1 && country.length() > 1){
				flag = true;
		}
		return flag;
	}
	@Override
	public String toString() {
		return    address1 + 
				(!address2.equals("")?("\n" + address2 ):address2) + "\n"
				+ city + ", " + state + (!state.equals("")? ",": "") + "\n"
				+ country + ", " +zipCode;
	}
}

package com.android.qburst.paypalMECL;
import java.io.Serializable;

import com.paypal.android.MECL.PayPalListener;

/*
 * Our PayPalListener class to get the device reference token from MECL
 */
public class ResultDelegate implements PayPalListener, Serializable {

	private static final long serialVersionUID = 1L;

	public void couldNotFetchDeviceReferenceToken() {
		//Initialization failed and we didn't get a token
		PaymentWebPage._deviceReferenceToken = null;
	}

	public void receivedDeviceReferenceToken(String token) {
		//Initialization was successful
		PaymentWebPage._deviceReferenceToken = token;
	}

}

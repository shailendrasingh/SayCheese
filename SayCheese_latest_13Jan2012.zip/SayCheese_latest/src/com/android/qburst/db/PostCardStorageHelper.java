package com.android.qburst.db;

import java.util.ArrayList;

import android.R;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.text.Html;

import com.android.qburst.ApplicationDataContainer;
import com.android.qburst.objects.AddressDetails;
import com.android.qburst.objects.Helper;
import com.android.qburst.objects.PostCard;
import com.android.qburst.objects.TextDetails;

/**
 * @author andrzej
 * cards.status field values N - new, P - payed, S - sent
 * texts.position field values 1 - front top, 2 - front bottom, 3 - back top, 4 - back bottom
 * address.type field values 1 - receiver, 2 - sender
 */
//run shell to to set up database connection
//adb -s emulator-5554 shell
//connect to data base 
//sqlite3 /data/data/com.android.qburst/databases/SayCheese.db
public class PostCardStorageHelper extends android.database.sqlite.SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 3;
    private static final String CARDS_TABLE_NAME = "cards";
    private static final String TEXTS_TABLE_NAME = "texts";
    private static final String ADDRESS_TABLE_NAME = "address";
    private static final String DATABASE_NAME = "SayCheese.db";
    private static final String CARDS_TABLE_CREATE =
                "CREATE TABLE " + CARDS_TABLE_NAME + " (" +
                "id" + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "status" + " INTEGER default '0', " +
                "paypal_tran_id" + " TEXT, " +
                "order_id" + " TEXT, " +           
                "card_date" + " TEXT," +
                "image_uri" + " TEXT," +
                "template_name" + " TEXT," +
                "last_modified" + " TEXT," +
                "snapshot_uri" + " TEXT," +
                "current_scale" + " FLOAT," +
                "current_x" + " FLOAT," +
                "current_y" + " FLOAT);";
    
    private static final String TEXTS_TABLE_CREATE =
            "CREATE TABLE " + TEXTS_TABLE_NAME + " (" +
            "card_id" + " INTEGER, " +
            "position" + " INTEGER," +
            "text" + " TEXT," +
            "font" + " TEXT," +
            "size" + " REAL," +
            "default_size" + " REAL," +
            "color" + " INTEGER," +
    		"FOREIGN KEY(card_id) REFERENCES " + CARDS_TABLE_NAME + "(id));";
    
    private static final String ADDRESS_TABLE_CREATE =
            "CREATE TABLE " + ADDRESS_TABLE_NAME + " (" +
            "card_id" + " INTEGER, " +
            "type" + " INTEGER," +          
			"full_name" + " TEXT," +
			"state" + " TEXT," +
			"address1" + " TEXT," +
			"address2" + " TEXT," +
			"city" + " TEXT," +
			"zip_code" + " TEXT," +
			"country" + " TEXT," +
			"email" + " TEXT," +
    		"FOREIGN KEY(card_id) REFERENCES " + CARDS_TABLE_NAME + "(id));";

    private ArrayList<PostCard> postCardArray;
    private Cursor c;
    private Context context;
    private Handler myHandler;
    private ApplicationDataContainer mAppDataHolder;
    
    public PostCardStorageHelper(Context myContext, Handler myHandler) {
        super(myContext, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = myContext;
        this.myHandler = myHandler;
        mAppDataHolder = (ApplicationDataContainer) context;
    }

	@Override
	public void onCreate(SQLiteDatabase db) {
        db.execSQL(CARDS_TABLE_CREATE);
        db.execSQL(TEXTS_TABLE_CREATE);
        db.execSQL(ADDRESS_TABLE_CREATE);
	}
	@Override
	public synchronized void close() {
		super.close();
	}

	public void clearDB(SQLiteDatabase database){
		database.execSQL("DROP TABLE IF EXISTS " + TEXTS_TABLE_NAME);
		database.execSQL("DROP TABLE IF EXISTS " + ADDRESS_TABLE_CREATE);
		database.execSQL("DROP TABLE IF EXISTS " + CARDS_TABLE_NAME);
	}

	@Override
	public void onUpgrade(SQLiteDatabase database, int arg1, int arg2) {
		database.execSQL("DROP TABLE IF EXISTS " + TEXTS_TABLE_NAME);
		database.execSQL("DROP TABLE IF EXISTS " + ADDRESS_TABLE_CREATE);
		database.execSQL("DROP TABLE IF EXISTS " + CARDS_TABLE_NAME);
		onCreate(database);		
	}
	
	public ArrayList<PostCard> getMyPostCards(){
        SQLiteDatabase cardsDB = getReadableDatabase();
        postCardArray = new ArrayList<PostCard>();
    	loadDraftCards(cardsDB);
        cardsDB.close();
		return postCardArray;
	}
	
	private int loadDraftCards(SQLiteDatabase cardsDB){
		String [] cols = {"id","status", "order_id", "paypal_tran_id", "card_date", "image_uri", 
				"template_name", "last_modified", "snapshot_uri", "current_scale", "current_x", "current_y"};
		c = cardsDB.query(CARDS_TABLE_NAME, cols, "status<4", null, null, null, "id");
		if (c.moveToFirst()){			
			do {				
				postCardArray.add(new PostCard(c.getInt(0), c.getInt(1), c.getString(2), c.getString(3), 
						c.getString(4), c.getString(5), c.getString(6), c.getString(7), c.getString(8),
						c.getFloat(9), c.getFloat(10), c.getFloat(11)));
			} while (c.moveToNext());
		}
		c.close();
		return postCardArray.size();
	}
	
	public String loadOneCardsDetils(int cardId){
		String ret = null;
		SQLiteDatabase cardsDB = getReadableDatabase();
		String [] cols = {"id","status", "order_id", "paypal_tran_id", "card_date", "image_uri", 
				"template_name", "last_modified", "snapshot_uri", "current_scale", "current_x", "current_y"};
		c = cardsDB.query(CARDS_TABLE_NAME, cols, "id=" + cardId, null, null, null, "id");
		if (c.moveToFirst()){
			PostCard postCard = null;
			postCard = new PostCard(c.getInt(0), c.getInt(1), c.getString(2), c.getString(3), 
					c.getString(4), c.getString(5), c.getString(6), c.getString(7), c.getString(8),
					c.getFloat(9), c.getFloat(10), c.getFloat(11));
			mAppDataHolder.setPostCardDetails(postCard);
			ret = c.getString(5);
		}
		c.close();
		cardsDB.close();
		return ret;
	}

	public void loadCardsTextDetails(int cardId){
		SQLiteDatabase cardsDB = getReadableDatabase();
		String [] cols = {"card_id", "position", "text", "font", "size", "default_size", "color"};
		c = cardsDB.query(TEXTS_TABLE_NAME, cols, "card_id=" + cardId, null, null, null, "card_id");
		if (c.moveToFirst()){
			TextDetails tempText;
			do {
				
				tempText = new TextDetails(Html.fromHtml(c.getString(2)), c.getString(3), 
						c.getInt(4), c.getInt(5), c.getInt(6), c.getInt(1), context);
						
				switch (tempText.getPosition()) {
	            case 1: 
	            		mAppDataHolder.setFrontTitleText(tempText);
	                    break;
	            case 2: 
	            		mAppDataHolder.setFrontDescText(tempText);
	                    break;
	            case 3:  
	            		mAppDataHolder.setBackText(tempText);
	                    break;           
	            default: 
	                    break;
				}
			} while (c.moveToNext());
		}
		c.close();
		cardsDB.close();
	}
	
	public void loadAddressDetails(int cardId){
		SQLiteDatabase cardsDB = getReadableDatabase();
		String [] cols = {"card_id", "type", "full_name", "state", "address1", "address2", "city", 
				"zip_code", "country", "email"};
		c = cardsDB.query(ADDRESS_TABLE_NAME, cols, "card_id=" + cardId, null, null, null, "card_id");
		if (c.moveToFirst()){
			AddressDetails tempAddress;
			do {			
				tempAddress = new AddressDetails(c.getInt(1), c.getString(2), c.getString(3), 
						c.getString(4), c.getString(5), c.getString(6), c.getString(7), c.getString(8), 
						c.getString(9));

				switch (tempAddress.getType()) {
	            case 1: 
	            		mAppDataHolder.setCardRecipient(tempAddress);
	                    break;
	            case 2: 
	            		mAppDataHolder.setCardSender(tempAddress);
	                    break;           
	            default: 
	                    break;
				}
			} while (c.moveToNext());
		}
		c.close();
		cardsDB.close();
	}

	public PostCard saveCard(String order_id, String paypal_tran_id, String image_uri, String template_name, 
			String card_date, String snapshotUri, float current_scale, float current_x, float current_y){
		PostCard newPC = null;
		ContentValues values = new ContentValues();
		values.put("status", PostCard.STATUS_CREATED);
		values.put("paypal_tran_id", paypal_tran_id);
		values.put("order_id", order_id);
		values.put("image_uri", image_uri);
		values.put("template_name", template_name);
		values.put("card_date", card_date);
		values.put("last_modified", card_date);
		values.put("snapshot_uri", snapshotUri);
		values.put("current_scale", current_scale);
		values.put("current_x", current_x);
		values.put("current_y", current_y);
		SQLiteDatabase cardsDB = this.getWritableDatabase();
		Cursor outc = null;
		try {
			cardsDB.insert(CARDS_TABLE_NAME, null, values);
			outc = cardsDB.rawQuery("select max(id) as max_id from " + CARDS_TABLE_NAME, null);
			outc.moveToFirst();
			int i = outc.getInt(0);
			newPC = new PostCard(i, PostCard.STATUS_CREATED, order_id, paypal_tran_id, card_date, image_uri, 
					template_name, card_date, snapshotUri, current_scale, current_x, current_y);	
			if (postCardArray == null){
				postCardArray = new ArrayList<PostCard>();
			}
			postCardArray.add(newPC);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			outc.close();
			cardsDB.close();
		}
		return newPC;		
	}

	public void saveTextDetails(int cardId, int textPosition, 
			String textBody, String fontName,  float textSize, float defaultTextSize, int textColor){
		ContentValues values = new ContentValues();
		values.put("card_id", cardId);
		values.put("position", textPosition);
		values.put("text", textBody);
		values.put("font", fontName);
		values.put("size", textSize);
		values.put("default_size", defaultTextSize);
		values.put("color", textColor);
		SQLiteDatabase cardsDB = this.getWritableDatabase();
		try {
			cardsDB.insert(TEXTS_TABLE_NAME, null, values);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cardsDB.close();
		}
	}
	
	public void saveAddressDetails(int cardId, int addressType, String fullName, 
			String state,String address1, String address2, String city, String zipCode, String country, String email){
		
		ContentValues values = new ContentValues();
		values.put("card_id", cardId);
		values.put("type", addressType);		
		values.put("full_name", fullName);
		values.put("state", state);
		values.put("address1", address1);
		values.put("address2", address2);
		values.put("city", city);
		values.put("zip_code", zipCode);
		values.put("country", country);		
		values.put("email", email);	
		SQLiteDatabase cardsDB = this.getWritableDatabase();
		try {
			cardsDB.insert(ADDRESS_TABLE_NAME, null, values);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			cardsDB.close();
		}
	}
	
	public void markPostCardPayed(PostCard p, String paypal_tran_id){
		SQLiteDatabase cardsDB=this.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put("status", PostCard.STATUS_PAYED);
		values.put("paypal_tran_id",paypal_tran_id);
		try {
			cardsDB.update(CARDS_TABLE_NAME, values, "id="+p.getId(), null);
			p.setStatus(PostCard.STATUS_PAYED);
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			cardsDB.close();
		}
	}
	public void markPostCardSent(PostCard p){
		SQLiteDatabase cardsDB=this.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put("status", PostCard.STATUS_SENT);
		try {
			cardsDB=this.getWritableDatabase();
			cardsDB.update(CARDS_TABLE_NAME, values, "id="+p.getId(), null);
			cardsDB.close();
			p.setStatus(PostCard.STATUS_SENT);
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			cardsDB.close();
		}
	}
	
	public void addOrderIdAndMarkAsSent(PostCard p){
		SQLiteDatabase cardsDB=this.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put("status", p.getStatus());
		values.put("order_id", p.getOrder_id());
		values.put("card_date", p.getCard_date());
		try {
			cardsDB=this.getWritableDatabase();
			cardsDB.update(CARDS_TABLE_NAME, values, "id="+p.getId(), null);
			cardsDB.close();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			cardsDB.close();
		}
	}
	
	public void updateCard(int cardId, String filePath, String snapshot_uri, float current_scale, 
			float current_x, float current_y){
		SQLiteDatabase cardsDB = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("image_uri", filePath);
		values.put("last_modified", Helper.nowDate()); //update card with current date
		values.put("snapshot_uri", snapshot_uri);
		values.put("current_scale", current_scale);
		values.put("current_x", current_x);
		values.put("current_y", current_y);
		try {
			cardsDB.update(CARDS_TABLE_NAME, values, "id="+cardId, null);
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			cardsDB.close();
		}
	}
	public void updateAddressDetails(int cardId, int addressType, String fullName, 
			String state, String address1, String address2, String city,String zipCode, String country, String email){
		
		ContentValues values = new ContentValues();	
		values.put("full_name", fullName);
		values.put("state", state);
		values.put("address1", address1);
		values.put("address2", address2);
		values.put("city", city);
		values.put("zip_code", zipCode);
		values.put("country", country);
		values.put("email", email);
		SQLiteDatabase cardsDB = this.getWritableDatabase();
		try {
			cardsDB.update(ADDRESS_TABLE_NAME, values, "card_id="+cardId+" and type="+addressType, null);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			cardsDB.close();
		}
	}
	
	public void updateTextDetails(int cardId, int textPosition, 
			String textBody, String fontName,  float textSize, int textColor){
		ContentValues values = new ContentValues();
		values.put("text", textBody);
		values.put("font", fontName);
		values.put("size", textSize);
		values.put("color", textColor);
		SQLiteDatabase cardsDB = this.getWritableDatabase();
		try {
			cardsDB.update(TEXTS_TABLE_NAME, values, "card_id="+cardId+" and position="+textPosition, null);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cardsDB.close();
		}
	}
	
	class PayedPostCardsSender extends AsyncTask<Void, String, Integer>{
		private Context context;
		public ProgressDialog pd;

		public PayedPostCardsSender(Context context){
			this.context=context;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pd=new ProgressDialog(context);
			pd.setMessage("Sending postcards...");
			pd.show();
		}

		@Override
		protected void onPostExecute(Integer result) {
			pd.dismiss();
			if (result<0){
				AlertDialog ad=new AlertDialog.Builder(context).create();
				ad.setMessage("Error occoured. Try again later...");
				ad.setIcon(R.drawable.ic_dialog_alert);
				Message msg=new Message();
				msg.setTarget(myHandler);
				ad.setButton("OK", msg);
				ad.show();
			}
		}
		@Override
		protected void onProgressUpdate(String... values) {
			pd.setMessage(values[0]);
		}
		@Override
		protected Integer doInBackground(Void... params) {
			int cnt=0;
			for (PostCard p: postCardArray){
				if (p.getStatus() == PostCard.STATUS_PAYED){
					try {
						//TODO dodać do kogo wysylamy +p.getReceiver_name());
						publishProgress("Sending to ");
						Thread.sleep(3000);
						webserviceSendPostCard(p);
						markPostCardSent(p);
						cnt++;
					} catch (Exception e) {
						e.printStackTrace();
						return -1;
					}
				}
			}
			return cnt;
		}		
	}
	
	public void sendPayedPostCards(Context context){
		
		PayedPostCardsSender task= new PayedPostCardsSender(context);
		task.execute();
	}

	private void webserviceSendPostCard(PostCard p) throws Exception {
		// TODO Auto-generated method stub
		throw new Exception("Unimplemented");
		
	}
	
}
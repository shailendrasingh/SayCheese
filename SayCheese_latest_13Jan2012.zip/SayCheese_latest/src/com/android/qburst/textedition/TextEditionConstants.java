package com.android.qburst.textedition;

public class TextEditionConstants {

	/**
	 * Built-In Font types
	 */
	final public static String typefaceSerif = "SERIF";
	final public static String typefaceSan = "SANS_SERIF";
	final public static String typefaceMono = "MONOSPACE";
	
	final public static String chooseColorRed = "Red";
	final public static String chooseColorGreen = "Green";
	final public static String chooseColorBlue = "Blue";
	final public static String chooseColorAlpha = "Alpha";
}

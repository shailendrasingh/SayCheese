package com.android.qburst;

import java.io.FileNotFoundException;
import java.net.URI;

import com.android.qburst.R;
import com.android.qburst.facebook.FacebookGalleryList;
import com.android.qburst.facebook.Utility;
import com.android.qburst.objects.Helper;
import com.android.qburst.objects.PostCard;
import com.flurry.android.FlurryAgent;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class DialogChoosePicture extends Activity {
	
	private static final int CAMERA_PIC_REQUEST = 1337;
	private static final int PICTURE_GALLERY_REQUEST = 2572;
	private static final int FACEBOOK_GALLERY_REQUEST = 9796;
	private ApplicationDataContainer mAppDataHolder;
	private Handler myHandler;

	private Button btnCancel, btnCamera, btnFacebook, btnLibrary;
	private OnClickListener buttonListener = new OnClickListener() {
	
	final private String FBEvent = "Choose pic from facebook";	
	final private String CameraCaptureEvent = "Choose pic from camera";
	final private String AlbumEvent =  "Choose pic from library";
	final private String CancelEvent = "Cancel picture choosing";
	
		public void onClick(View v) {
			switch(v.getId()){
				case R.id.btnChoosePicFacebook:
					FlurryAgent.logEvent(FBEvent);
					Intent facebookIntent = new Intent(DialogChoosePicture.this, FacebookGalleryList.class); 
					startActivityForResult(facebookIntent, FACEBOOK_GALLERY_REQUEST);
					break;
				case R.id.btnChoosePicCamera:
					FlurryAgent.logEvent(CameraCaptureEvent);
					Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); 
					startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);
					break;
				case R.id.btnChoosePicLibrary:
					FlurryAgent.logEvent(AlbumEvent);
					Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
					photoPickerIntent.setType("image/*");
					startActivityForResult(photoPickerIntent, PICTURE_GALLERY_REQUEST);
					break;
				case R.id.btnChoosePicCancel:
					FlurryAgent.logEvent(CancelEvent);
					finish();
					break;
				default: break;
			}		
			
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.choose_picture_main);
		mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
		myHandler = new Handler();
		findControls();
		setListeners();
	}
	
	private void setListeners() {
		btnCancel.setOnClickListener(buttonListener);
		btnCamera.setOnClickListener(buttonListener);
		btnFacebook.setOnClickListener(buttonListener);
		btnLibrary.setOnClickListener(buttonListener);		
	}
	private void findControls() {
		btnCancel = (Button) findViewById(R.id.btnChoosePicCancel);
		btnLibrary = (Button) findViewById(R.id.btnChoosePicLibrary);
		btnFacebook = (Button) findViewById(R.id.btnChoosePicFacebook);
		btnCamera = (Button) findViewById(R.id.btnChoosePicCamera);	
	}
	
    public synchronized void onActivityResult(final int requestCode, int resultCode, final Intent data) {
    	if (resultCode == RESULT_OK) {  
	    	switch (requestCode) {
	    		case CAMERA_PIC_REQUEST:
	    			
	    			Bundle b = data.getExtras();
                    Bitmap pic = b.getParcelable("data");
                    mAppDataHolder.setCardFrontImage(pic);
	    			setResult(RESULT_OK, getIntent());
	                finish();
	    			break;
	    		case PICTURE_GALLERY_REQUEST:
	    			
	    			Uri selectedImage = null;
	    			try{
	    				selectedImage = data.getData();
	    			}catch (Exception e) {
						Toast.makeText(this, "URI: "+e.getMessage(), Toast.LENGTH_LONG).show();
					}
					try {
						mAppDataHolder.setCardFrontImage(getFotoFromDataStorage(selectedImage));
					}catch (FileNotFoundException e) {
						Toast.makeText(this, selectedImage.getPath(), Toast.LENGTH_LONG).show();
					}catch (NullPointerException e) {
							Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
					}
					setResult(RESULT_OK, getIntent());
		            finish();
	    			break;
	    		case FACEBOOK_GALLERY_REQUEST:
	    			loadPhotoFromFacebook(this, data.getStringExtra("filePath"), data.getStringExtra("fileName"));
	    			break;
	    		default: 
	    			break;
	    	}
    	 } else {
 	        Log.w("DialogChoosePicture", "Warning: activity result not ok");  
 	    }
    }
    
    private Bitmap getFotoFromDataStorage(Uri fileName) throws FileNotFoundException,NullPointerException{
        BitmapFactory.Options bfo = new BitmapFactory.Options();
        bfo.inSampleSize = 2;
        Bitmap mBitmap = null;
        String realPath = Helper.getRealPathFromURI(this, fileName);
    	savePathToLoadedFile(mAppDataHolder, realPath);
    	mBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(fileName), null, bfo);
		return mBitmap;
    }
    
    private void loadPhotoFromFacebook(Context context, String filePath, String fileName){
    	LoadFacebookPhoto task= new LoadFacebookPhoto(context, filePath, fileName);
		task.execute();
    }
    
	class LoadFacebookPhoto extends AsyncTask<Void, String, Integer> {
		private Context mContext;
		private String mFilePath;
		private String mFileName;
		private ProgressDialog pd;
		final static private String FBCacheFileName = "facebookimage";
		private String downloadingFBImageMsg = "Downloading picture from Facebook :";
		public LoadFacebookPhoto(Context context, String filePath, String fileName){
			mContext = context;
			mFilePath = filePath;
			mFileName = fileName;
			downloadingFBImageMsg+=mFileName;
		}

		@Override
		protected void onPreExecute() {
//			super.onPreExecute();
			pd = new ProgressDialog(mContext);
			pd.setMessage(downloadingFBImageMsg);
			pd.show();
		}

		@Override
		protected void onPostExecute(Integer result) {
			pd.dismiss();
			if (result < 0){
				AlertDialog ad = new AlertDialog.Builder(mContext).create();
				ad.setMessage("Error occoured. Try again later...");
				ad.setIcon(android.R.drawable.ic_dialog_alert);
				Message msg = new Message();
				msg.setTarget(myHandler);
				ad.setButton("OK", msg);
				ad.show();
			}
			setResult(RESULT_OK, getIntent());
            finish();
		}
		@Override
		protected void onProgressUpdate(String... values) {
			pd.setMessage(values[0]);
		}
		@Override
		protected Integer doInBackground(Void... params) {
			int ret = 0;
			try {
				publishProgress(downloadingFBImageMsg);
//				Thread.sleep(3000);
				mAppDataHolder.setCardFrontImage(Utility.getBitmap(mFilePath));
				String filePath = Helper.saveImageInExternalCacheDir(mContext, mAppDataHolder.getCardFrontImage(), FBCacheFileName);
				savePathToLoadedFile(mAppDataHolder, filePath);
			} catch (Exception e) {
//				e.printStackTrace();
				return -1;
			}
			return ret;
		}		
	}
	
	private void savePathToLoadedFile(ApplicationDataContainer appDataHolder, String mFilePath){
		if(appDataHolder.getPostCardDetails() != null){
			appDataHolder.getPostCardDetails().setImageUri(mFilePath);
		} else {
			appDataHolder.setPostCardDetails(new PostCard(mFilePath));
		}
	}
}

package com.android.qburst;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.android.qburst.coverflow.CoverFlow;
import com.android.qburst.coverflow.CoverFlowAdapter;

public class Simple3DGallery extends BaseActivity {
	
	private int galleryType = 0;
	public static int CREATE_CARD_REQUEST_CODE  = 1231;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        if (getIntent().getExtras() != null) { 
        	galleryType = getIntent().getIntExtra("galleryType", 0);
        } 
          
        //Adding CowerFlow show 3D slides     
        CoverFlow coverFlow = new CoverFlow(this);
        final CoverFlowAdapter coverImageAdapter = new CoverFlowAdapter(this, galleryType);
		coverFlow.setAdapter(coverImageAdapter);
		coverFlow.setSpacing(-25);
		coverFlow.setSelection(0, true);
		coverFlow.setAnimationDuration(1000);
		setContentView(coverFlow);
		
		coverFlow.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> adapter, View arg1, int position, long arg3) {
				ApplicationDataContainer mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
				mAppDataHolder.setCardRecipient(null);
				mAppDataHolder.setCardSender(null);
				mAppDataHolder.setTexts();
				Intent intentCreateCard = new Intent(getApplicationContext(), CreateCard.class);
				mAppDataHolder.getPostCardDetails().setTemplateName(coverImageAdapter.getItemName(position));
				startActivityForResult(intentCreateCard, CREATE_CARD_REQUEST_CODE);
			}

        });		
    }
}

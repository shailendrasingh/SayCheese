package com.android.qburst;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class HelpOptionText extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.helpoption_details);
		findControls();
		setListeners();
	}
	private void setListeners() {
		
	}
	private void findControls() {
		
		TextView helpOptionDetailsTitle = (TextView) findViewById(R.id.helpOptionDetailsTitle);
		helpOptionDetailsTitle.setText(getIntent().getStringExtra("title"));
		
		TextView helpOptionDetailsBody = (TextView) findViewById(R.id.helpOptionDetailsBody);
		helpOptionDetailsBody.setText(getIntent().getStringExtra("body"));
	}
}

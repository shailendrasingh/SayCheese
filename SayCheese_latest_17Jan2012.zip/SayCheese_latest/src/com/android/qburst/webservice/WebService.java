package com.android.qburst.webservice;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
//import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;


import android.util.Log;

/** Web service connection. */
public class WebService {
 
	/** Sync. object */
	Object syncObject;
	/** HTTP Client. */
    private DefaultHttpClient httpClient;
    /** Web service URL. */
    private String webServiceUrl;  
    /** 20000 milliseconds. */
    private final int timeout = 20000;
    /** Response OK value. */
    private final int responseOK = 200;
    /** Response created value. */
    private final int responseCreated = 201;
 
    /**
     * Create web service connection.
     * @param serviceName Web service URL
     */
    public WebService(String serviceName) {
        HttpParams myParams = new BasicHttpParams();
        //myParams.setParameter("maxPostSize", 0);
        
        HttpConnectionParams.setConnectionTimeout(myParams, timeout);
        HttpConnectionParams.setSoTimeout(myParams, timeout);
        syncObject = new Object();
        httpClient = new DefaultHttpClient(myParams);
        webServiceUrl = serviceName;
    }
 
    /**
     * Invoke web service method via HTTP POST.
     * @param url	Web service method name
     * @param json	Web service method parameters
     * @return Web service response
     * @throws ClientProtocolException .
     * @throws IOException .
     * @throws JSONException .
     */
    public String postJSON(String url, JSONObject json)
    	throws ClientProtocolException, IOException, JSONException {
    	synchronized (syncObject) {
    	    String ret;
    	    HttpResponse response;
    		
    		Log.d("JSON POST", json.toString());
	        HttpPost httppost = new HttpPost(webServiceUrl + url);
	        httppost.addHeader("Content-type", "application/json");
	        StringEntity se = new StringEntity(json.toString());
	        se.setContentType("application/json");
	        se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
	        httppost.setEntity(se);
	        
	        Log.i( "POST","execute: " + httppost.getRequestLine() );
	        
	        response = httpClient.execute(httppost);
	        HttpEntity entity = response.getEntity();
	        
	        if (entity != null 
	        		&& (response.getStatusLine().getStatusCode() == responseCreated 
	        		    || response.getStatusLine().getStatusCode() == responseOK)) {
	        	ret = EntityUtils.toString(entity);
	        	
	        	Log.i("POST", url + " " + ret);
	        	return ret;
	        } else {
	        	Log.e("JSON-POST: ", "failed");
	        	return null;
	        }
    	}
    }
    
    public String post(String url, String filename, InputStream is, HashMap<String,Object> propertiers)
        	throws Exception {
        	synchronized (syncObject) {
        	    String ret;
        	    HttpResponse response;
        	    String fullUrl = webServiceUrl + url;
        	    List<BasicNameValuePair> nameValuePairs = new ArrayList<BasicNameValuePair>();
        	    for (String key : propertiers.keySet()) {
        	    	nameValuePairs.add(new BasicNameValuePair(key, propertiers.get(key).toString()));
        	    }
        	    
    	        HttpPost httppost = new HttpPost(fullUrl);
    	        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
    	        response = httpClient.execute(httppost);
    	        HttpEntity entity = response.getEntity();
    	        if (entity != null && (response.getStatusLine().getStatusCode() == responseCreated 
    	        		    || response.getStatusLine().getStatusCode() == responseOK)) {
    	        	
    	        	ret = EntityUtils.toString(entity);
    	        	Log.i("POST", filename);
    	        	Log.i("UPLOAD", propertiers.toString());
   	        		postImage(fullUrl, filename, is);
   	        	
    	        	return ret;
    	        } else {
    	        	Log.e("POST", "failed");
    	        	return null;
    	        }
        	}
        }
  
    public void postImage(String urlServer, String fileName, InputStream is) throws Exception {
    	HttpURLConnection connection = null;
    	DataOutputStream outputStream = null;
    	

    	String pathToOurFile = null;
    	pathToOurFile = fileName ;
    	
    	String lineEnd = "\r\n";
    	String twoHyphens = "--";
    	String boundary =  "*****";

    	int bytesRead, bytesAvailable, bufferSize;
    	byte[] buffer;
    	int maxBufferSize = 1*1024*1024;

    	FileInputStream fileInputStream = null;
    	if(is == null){
    		fileInputStream = new FileInputStream(new File(pathToOurFile) );
    		is = fileInputStream;
    	}

    	URL url = new URL(urlServer);
    	connection = (HttpURLConnection) url.openConnection();

    	// Allow Inputs & Outputs
    	connection.setDoInput(true);
    	connection.setDoOutput(true);
    	connection.setUseCaches(false);

    	// Enable POST method
    	connection.setRequestMethod("POST");

    	connection.setRequestProperty("Connection", "Keep-Alive");
    	connection.setRequestProperty("Content-Type", "multipart/form-data;boundary="+boundary);

    	outputStream = new DataOutputStream( connection.getOutputStream() );
    	outputStream.writeBytes(twoHyphens + boundary + lineEnd);
    	outputStream.writeBytes("Content-Disposition: form-data; name=\"uploadedfile\";filename=\"" + pathToOurFile +"\"" + lineEnd);
    	outputStream.writeBytes(lineEnd);

    	bytesAvailable = is.available();
    	bufferSize = Math.min(bytesAvailable, maxBufferSize);
    	buffer = new byte[bufferSize];

    	// Read file
    	bytesRead = is.read(buffer, 0, bufferSize);

    	while (bytesRead > 0){
	    	outputStream.write(buffer, 0, bufferSize);
	    	
	    	bytesAvailable = is.available();
	    	bufferSize = Math.min(bytesAvailable, maxBufferSize);
	    	
	    	bytesRead = is.read(buffer, 0, bufferSize);
    	}

    	outputStream.writeBytes(lineEnd);
    	outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

    	// Responses from the server (code and message)
    	int serverResponseCode = connection.getResponseCode();
    	String serverResponseMessage = connection.getResponseMessage();

    	is.close();
    	outputStream.flush();
    	outputStream.close();
	}
    
    
    
    /**
     * Invoke web service method via HTTP GET.
     * @param methodName Web service method name
     * @param params	 Web service method parameters
     * @return Web service response
     * @throws IOException .
     * @throws ParseException .
     */
    public String get(String methodName, Map<String, String> params) 
    		throws ParseException, IOException {
    	synchronized (syncObject){
	        String getUrl = webServiceUrl + methodName;
	        String ret;
    	    HttpResponse response;
    	    HttpGet httpGet;
	        
	        if (params != null && params.size() > 0) {
		        int i = 0;
		        for (Map.Entry<String, String> param : params.entrySet()) {
		            if (i == 0) {
		                getUrl += "?data=%7B";
		            } else {
		            	try {
		            		getUrl += URLEncoder.encode(",", "UTF-8");
		                } catch (UnsupportedEncodingException e) {
		                    e.printStackTrace(); 
		                }
		            }
	                getUrl += URLEncoder.encode("\"" + param.getKey()
	                		+ "\": \"" + param.getValue() + "\"", "UTF-8");
		            i++;
		        }
		        getUrl += "%7D";
	        }
	 
	        httpGet = new HttpGet(getUrl);
	        Log.d("httpGet: ", URLDecoder.decode(getUrl));
	        Log.d("httpGet: ", getUrl);
	    	response = httpClient.execute(httpGet);
	        ret = EntityUtils.toString(response.getEntity());
	        Log.i("get", ret);
	 
	        return ret;
    	}        
    }
 
}

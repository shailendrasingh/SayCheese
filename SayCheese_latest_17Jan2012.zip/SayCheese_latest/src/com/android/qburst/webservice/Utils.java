package com.android.qburst.webservice;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.serialization.SoapObject;

import com.android.qburst.objects.AddressDetails;
import com.android.qburst.objects.AddressFromZip;
import com.android.qburst.objects.PostCard;

import android.graphics.Bitmap;
import android.util.Log;

public class Utils {
		
	private final static WebServiceSOAP WSSOAP = new WebServiceSOAP("http://www.say-cheese.com/",
			"http://strat-agile.com/saycheeseaddress/service.asmx?WSDL");
	
	private final static WebService WS = new WebService("http://175.41.140.188/saycheeseAPI/");
	
	public static AddressFromZip getAddress(String postalCode) throws Exception {
		String[] obj = new String[2];
		obj[0] = "PostCode";
		obj[1] = postalCode;
		
		SoapObject so = WSSOAP.run(obj, "http://www.say-cheese.com/GetAddress", "GetAddress");
		String result = so.getPropertyAsString("GetAddressResult");
		
		Log.i("res",result);
		
		return new AddressFromZip(
				result.substring(0, result.indexOf('~')),
				result.substring(result.indexOf("~")+1,result.indexOf('~', (result.indexOf("~")+1))),
				result.substring(result.indexOf('~', (result.indexOf("~")+1))+1)
				);
	}

	public static JSONObject sendCard(PostCard card, AddressDetails recipientAddressDetails,
			AddressDetails senderAddressDetails, String deviceId, String deviceType, JSONObject data)
					throws Exception {
		
		JSONObject address = new JSONObject();
			address.put("recipient", addressToJSONObject(recipientAddressDetails));
			address.put("sender", addressToJSONObject(senderAddressDetails));
			
		JSONObject device = new JSONObject();
			device.put("id", deviceId);
			device.put("type", deviceType);
			
		HashMap<String,Object> properties = new HashMap<String,Object>();
		properties.put("templateId", card.getTemplateName());
		properties.put("address", address);
		properties.put("device", device);
		properties.put("data", data);
	
		String result = WS.post("upload.php/",card.getImageUri(), null, properties);
		Log.i("JSON", result);
		return result != null ? new JSONObject(result): null;
	}
	
	public static JSONObject sendCard(PostCard card, AddressDetails recipientAddressDetails,
			AddressDetails senderAddressDetails, String deviceId, String deviceType, JSONObject data, InputStream is)
					throws Exception {
		
		JSONObject address = new JSONObject();
			address.put("recipient", addressToJSONObject(recipientAddressDetails));
			address.put("sender", addressToJSONObject(senderAddressDetails));
			
		JSONObject device = new JSONObject();
			device.put("id", deviceId);
			device.put("type", deviceType);
			
		HashMap<String,Object> properties = new HashMap<String,Object>();
		properties.put("templateId", card.getTemplateName());
		properties.put("address", address);
		properties.put("device", device);
		properties.put("data", data);
		
		String result = WS.post("upload.php/", card.getImageUri(), is, properties);
		Log.i("JSON", result);
		return result != null ? new JSONObject(result): null;
	}
	
	
	private static JSONObject addressToJSONObject(AddressDetails address){
		JSONObject jAddress = new JSONObject();
		try {
			jAddress.put("address1", address.getAddress1());
			jAddress.put("address2", address.getAddress2());
			jAddress.put("city", address.getCity());
			jAddress.put("country", address.getCountry());
			jAddress.put("email", address.getEmail());
			jAddress.put("name", address.getFullName());
			jAddress.put("state", address.getState());
			jAddress.put("zipcode", address.getZipCode());
		} catch (JSONException e) {
			Log.e("Utils","addressToJson: "+e.getMessage());
		}
		return jAddress;
		
	}

	public static JSONObject sendCardTest() {
		JSONObject recipientAddress = null, senderAddress = null, data = null; 
		String deviceId = null, deviceType = null;
		try {
		recipientAddress = new JSONObject();
			recipientAddress.put("address1", "Address Line 1");
			recipientAddress.put("address2", "Address Line 2");
			recipientAddress.put("city", "Singapore");
			recipientAddress.put("country", "Singapore");
			recipientAddress.put("email", "recipient@saycheese.com");
			recipientAddress.put("name", "Recipient");
			recipientAddress.put("state", "Singapore");
			recipientAddress.put("zipcode", "692071");
		senderAddress = new JSONObject();
			senderAddress.put("address1", "Address Line 1");
			senderAddress.put("address2", "Address Line 2");
			senderAddress.put("city", "Singapore");
			senderAddress.put("country", "Singapore");
			senderAddress.put("email", "sender@saycheese.com");
			senderAddress.put("name", "Sender");
			senderAddress.put("state", "Singapore");
			senderAddress.put("zipcode", "692071");
		deviceId = "00112233-4455-6677-8899-AABBCCDDEEFF";
		deviceType = "Android Simulator";
				
		data = new JSONObject(
				"{" +
			"\"frame\" : \"{{0, 0}, {336, 226}}\"," +
			"\"views\" : [" +
			"{" +
			"\"properties\" : {" +
			"\"image\" : \"\"" +
			"}," +
			"\"type\" : \"SCBackgroundView\"," +
			"\"view_attributes\" : {" +
			"\"color\" : \"{1.000000,1.000000,1.000000,0.000000}\"," +
			"\"frame\" : \"{{0, 0}, {336, 226}}\"," +
			"\"transform\" : \"[1, 0, 0, 1, 0, 0]\"" +
			"}" +
			"}," +
			"{" +
			"\"properties\" : {" +
			"\"editable\" : true," +
			"\"image\" : \"ph_1325158575.png\"," +
			"\"offset\" : \"{0, 0}\"," +
			"\"placeholderImage\" : \"\"," +
			"\"zoomScale\" : 1" +
			"}," +
			"\"type\" : \"SCPhotoView\"," +
			"\"view_attributes\" : {" +
			"\"color\" : \"{1.000000,1.000000,1.000000,0.000000}\"," +
			"\"frame\" : \"{{0, 0}, {336, 226}}\"," +
			"\"transform\" : \"[1, 0, 0, 1, 0, 0]\"" +
			"}" +
			"}," +
			"{" +
			"\"properties\" : {" +
			"\"image\" : \"textbg.png\"" +
			"}," +
			"\"type\" : \"SCBackgroundView\"," +
			"\"view_attributes\" : {" +
			"\"color\" : \"{1.000000,1.000000,1.000000,0.000000}\"," +
			"\"frame\" : \"{{7, 19}, {132, 184}}\"," +
			"\"transform\" : \"[1, 0, 0, 1, 0, 0]\"" +
			"}" +
			"}," +
			"{" +
			"\"properties\" : {" +
			"\"default_size\" : 18," +
			"\"editable\" : true," +
			"\"fontColor\" : \"{0.430000,0.000000,0.090000,1.000000}\"," +
			"\"fontName\" : \"IskoolaPota-Bold\"," +
			"\"size\" : 18," +
			"\"text\" : \"Gong Xi\nFa Chai!\"" +
			"}," +
			"\"type\" : \"SCTextView\"," +
			"\"view_attributes\" : {" +
			"\"color\" : \"{1.000000,1.000000,1.000000,0.000000}\"," +
			"\"frame\" : \"{{16, 25}, {111, 50}}\"," +
			"\"transform\" : \"[1, 0, 0, 1, 0, 0]\"" +
			"}" +
			"}," +
			"{" +
			"\"properties\" : {" +
			"\"default_size\" : 12," +
			"\"editable\" : true," +
			"\"fontColor\" : \"{0.740000,0.000000,0.120000,1.000000}\"," +
			"\"fontName\" : \"IskoolaPota-Bold\"," +
			"\"size\" : 12," +
			"\"text\" : \"May you be happy\nand prosperous!\nGood fortunes as\nyou" +
			"" +
			"wish.\"" +
			"" +
			"}," +
			"\"type\" : \"SCTextView\"," +
			"\"view_attributes\" : {" +
			"\"color\" : \"{1.000000,1.000000,1.000000,0.000000}\"," +
			"\"frame\" : \"{{16, 112}, {111, 80}}\"," +
			"\"transform\" : \"[1, 0, 0, 1, 0, 0]\"" +
			"}" +
			"}" +
			"" +
			"]" +
			"" +
			"}"
+"}"
			);
		} catch (Exception ex) {
			Log.e("Utils","ex: "+ex.getMessage());
		}
		try {
			return sendCard(null,
					new AddressDetails(
						AddressDetails.TYPE_RECEIVER, "Recipient","Singapore",
						"Address Line 1","Address Line 2","Singapore","692071",
						"Singapore","recipient@saycheese.com"), 
					new AddressDetails(AddressDetails.TYPE_SENDER, "Sender","Singapore",
						"Address Line 1","Address Line 2","Singapore","692071",
						"Singapore","sender@saycheese.com"),
					deviceId, deviceType, data);
		} catch (Exception ex) {
			Log.e("Utils","ex2: "+ex.getMessage());
		}
		return null;
	}	
}
package com.android.qburst.paypalMECL;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.qburst.AddAddress;
import com.android.qburst.ApplicationDataContainer;
import com.android.qburst.CreateCard;
import com.android.qburst.R;
import com.android.qburst.objects.AddressDetails;

public class PaymentMECL extends Activity implements OnClickListener  {
		
	private Button editSender, editRecipient;
	private ApplicationDataContainer mAppDataHolder;
	private TextView recipientName;
	private TextView senderName;
//	private TextView paymentPrice;
	protected static final int EDIT_ADDRESSS_REQUEST_CODE = 21;
	protected static final int PAYPAL_WEBPAGE = 22;
	private Button btnPay;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.payment_confirmation);
		mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
		findControls();
		fillForms();
		setListeners();
    }
        
	private void setListeners() {
		editSender.setOnClickListener(this);
		editRecipient.setOnClickListener(this);
		btnPay.setOnClickListener(this);
	}
	
	private void fillForms() {
		if (mAppDataHolder.getCardRecipient() != null && mAppDataHolder.getCardRecipient().checkIfAllDataIsProvidedForRecepient() ) {
			AddressDetails recipient = mAppDataHolder.getCardRecipient();
			recipientName.setText(recipient.getFullName() + "\n" + recipient.toString());
//			if(recipient.getCountry().equalsIgnoreCase("singapore")) {
//				paymentPrice.setText("$2.90");
//			} else { 
//				paymentPrice.setText("$3.90");
//			}
		} else {
			recipientName.setText("[No data]\n\n\n\n");
//			paymentPrice.setText("Select recipient to see the price");
		}
		
		if (mAppDataHolder.getCardSender() != null && mAppDataHolder.getCardSender().checkIfAllDataIsProvidedForSender() ) {
			AddressDetails sender = mAppDataHolder.getCardSender();
			senderName.setText(sender.getFullName() + "\n" + sender.toString());
		} else {
			senderName.setText("[No data]\n\n\n\n");
		}
	}
	
	private void findControls() {
		editSender = (Button) findViewById(R.id.btnEditSender);
		editRecipient = (Button) findViewById(R.id.btnEditRecipient);
		
		recipientName = (TextView) findViewById(R.id.paymentConfirmationRecipientName);
		senderName = (TextView) findViewById(R.id.paymentConfirmationSenderName);
		
		btnPay = (Button) findViewById(R.id.btn_toPayPalWebPage);
		
//		paymentPrice = (TextView) findViewById(R.id.paymentConfirmationPrice);
	}
  
	public void onClick(View v) {
		if(v == btnPay) { 
			boolean done = checkIfAllDataIsProvided();
			if(done) {
				Intent toPayPalWebPage = new Intent(v.getContext(), PaymentWebPage.class);
		    	startActivityForResult(toPayPalWebPage, PAYPAL_WEBPAGE);
			} else {
				Toast.makeText(v.getContext(), "Please fill all data before proceding", Toast.LENGTH_LONG).show();
			}
		} else if (v == editRecipient) {
			Intent editAddress = new Intent(getApplicationContext(), AddAddress.class);
			editAddress.putExtra("editedText", CreateCard.EDITED_RECEIVER_ADDRESS);
			startActivityForResult(editAddress, EDIT_ADDRESSS_REQUEST_CODE);
		} else if (v == editSender) {
			Intent editAddress = new Intent(getApplicationContext(), AddAddress.class);
			editAddress.putExtra("editedText", CreateCard.EDITED_SENDER_ADDRESS);
			startActivityForResult(editAddress, EDIT_ADDRESSS_REQUEST_CODE);
		}
	}
	
	private boolean checkIfAllDataIsProvided() {
		AddressDetails r = mAppDataHolder.getCardRecipient();
		AddressDetails s = mAppDataHolder.getCardSender();
		if (r == null || s == null) return false;
		if (!r.checkIfAllDataIsProvidedForRecepient() || !s.checkIfAllDataIsProvidedForSender()) return false;
		
		return true;
	}

	public void onActivityResult(int requestCode, int resultCode, Intent data) {   	

		switch(requestCode) {
			case(EDIT_ADDRESSS_REQUEST_CODE):
				if (resultCode == RESULT_OK) {
					fillForms();
				}
			case(PAYPAL_WEBPAGE):
				if (resultCode == RESULT_OK) {
					//TODO 
				}
		}
	}
}
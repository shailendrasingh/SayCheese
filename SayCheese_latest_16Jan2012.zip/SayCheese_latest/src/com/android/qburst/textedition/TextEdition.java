package com.android.qburst.textedition;

import com.android.qburst.ApplicationDataContainer;
import com.android.qburst.BaseActivity;
import com.android.qburst.CreateCard;
import com.android.qburst.R;
import com.android.qburst.objects.Helper;
import com.android.qburst.objects.TextDetails;
import com.android.qburst.textedition.ColorPickerDialog.OnColorChangedListener;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.text.Html;


public class TextEdition extends BaseActivity {
	

	/** Font screen. */
	private static final int CHOOSEFONT_REQUEST_CODE = 1;
	
	/** Color screen. */
	private static final int CHOOSECOLOR_REQUEST_CODE = 2;
	
	/** Size screen. */
	private static final int CHOOSESIZE_REQUEST_CODE = 3;
	/**	which screen is active now. */
	Context context = this;

	private Button btnFont, btnColor, btnSize, btnDone;
	private EditText txtPreviewText;
	private ApplicationDataContainer mAppDataHolder;
	private TextDetails details;
	
	private OnClickListener btnViewListener = new OnClickListener() {
		
		public void onClick(View v) {
			Intent editionOption;
			switch(v.getId()){
				case R.id.btnEditTextFont:
					editionOption = new Intent(context, ChooseFont.class);
					startActivityForResult(editionOption, CHOOSEFONT_REQUEST_CODE);
					break;
				case R.id.btnEditTextColor:
					ColorPickerDialog mColorPickerDialog = new ColorPickerDialog(TextEdition.this, new OnColorChangedListener() {
							
							public void colorChanged(int color) {
								// TODO Auto-generated method stub
								details.setTextColor(color);
								txtPreviewText.setTextColor(color);
							}
					}, 0);
					mColorPickerDialog.show();
					break;
				case R.id.btnEditTextSize:
					editionOption = new Intent(context, ChooseSize.class);
					editionOption.putExtra("size", details.getTextSize());
					editionOption.putExtra("defaultsize", details.getDefualtTextSize());
					startActivityForResult(editionOption, CHOOSESIZE_REQUEST_CODE);
					break;
				case R.id.btnEditTextDone:
					details.setTextBody(Html.fromHtml(txtPreviewText.getText().toString()));
					int which = getIntent().getIntExtra("which", -1);
					switch (which) {  
			        case CreateCard.EDIT_TEXT_REQUEST_CODE_FRONT_TITLE:
			        		mAppDataHolder.setFrontTitleText(details);
			            break;
			        case CreateCard.EDIT_TEXT_REQUEST_CODE_FRONT_DESC:
			        		mAppDataHolder.setFrontDescText(details);
			            break;
			        case CreateCard.EDIT_TEXT_REQUEST_CODE_BACK_TEXT:  
			        		mAppDataHolder.setBackText(details);
			            break;
			        default: 
			            	break;
					}
					setResult(RESULT_OK);
					finish();
					break;
				default: 
	            	break;
			}
		}
	};
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.text_edition_main);
        findControls();
        setListeners();
        setText();
    }

	private void setText() {
		int which = getIntent().getIntExtra("which", -1);
		switch (which) {  
        case CreateCard.EDIT_TEXT_REQUEST_CODE_FRONT_TITLE: 
        	if (mAppDataHolder.getFrontTitleText() != null ) {
        		details = mAppDataHolder.getFrontTitleText();
        	}
            break;
        case CreateCard.EDIT_TEXT_REQUEST_CODE_FRONT_DESC:
        	if (mAppDataHolder.getFrontDescText() != null ) {
        		details = mAppDataHolder.getFrontDescText();
        	}
            break;
        case CreateCard.EDIT_TEXT_REQUEST_CODE_BACK_TEXT: 
        	if (mAppDataHolder.getBackText() != null ) {
        		details = mAppDataHolder.getBackText();
        	}
            break;       
        default: 
            	break;
		}
		txtPreviewText.setText(details.getTextBody());
		txtPreviewText.setTypeface(details.getFont());
		txtPreviewText.setTextSize(details.getTextSize());
		txtPreviewText.setTextColor(details.getTextColor());
	}

	private void findControls() {
        mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
		btnFont = (Button) findViewById(R.id.btnEditTextFont);
		btnColor = (Button) findViewById(R.id.btnEditTextColor);
		btnSize = (Button) findViewById(R.id.btnEditTextSize);
		btnDone = (Button) findViewById(R.id.btnEditTextDone);
		txtPreviewText = (EditText) findViewById(R.id.etResultingText);
	}
	
	private void setListeners() {
		btnColor.setOnClickListener(btnViewListener);
		btnFont.setOnClickListener(btnViewListener);
		btnSize.setOnClickListener(btnViewListener);
		btnDone.setOnClickListener(btnViewListener);
		
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		switch(requestCode) {
			case(CHOOSEFONT_REQUEST_CODE):
				if (resultCode == RESULT_OK) {
					String fontName = data.getStringExtra("font");
					details.setFontName(fontName);
					Typeface font = Helper.getFont(fontName, context);
					details.setFont(font);
					txtPreviewText.setTypeface(font);
				}
				break;
			case(CHOOSECOLOR_REQUEST_CODE):
				if (resultCode == RESULT_OK) {
					details.setTextColor(data.getIntExtra("color", details.getTextColor()));
					txtPreviewText.setTextColor(details.getTextColor());
				}
				break;
			case(CHOOSESIZE_REQUEST_CODE):
				if (resultCode == RESULT_OK) {
					details.setTextSize(data.getFloatExtra("size", details.getTextSize()));
					txtPreviewText.setTextSize(details.getTextSize());	
				}
				break;
		} // End of Switch case
	}
}
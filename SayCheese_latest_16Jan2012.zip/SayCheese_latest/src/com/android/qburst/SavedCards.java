package com.android.qburst;

import java.util.ArrayList;

import com.android.qburst.R;
import com.android.qburst.db.PostCardStorageHelper;
import com.android.qburst.objects.Helper;
import com.android.qburst.objects.PostCard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Handler.Callback;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;

public class SavedCards extends Activity implements Callback  {

	private TabHost tabhostSavedCards;
	private Context context = this;
	private ListView savedCardsList, draftCardsList;
	private PostCardStorageHelper storageHelper=null;
	Handler myHandler;
	ArrayList<PostCard> myDraftCards = new ArrayList<PostCard>();
	ArrayAdapter<PostCard> myDraftCardsAdapter;
	ArrayList<PostCard> mySavedCards = new ArrayList<PostCard>();
	ArrayAdapter<PostCard> mySavedCardsAdapter;
	private ApplicationDataContainer mAppDataHolder;
		
	private OnItemClickListener cardListener = new OnItemClickListener() {

		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) {
			PostCard postCard = (PostCard) arg0.getItemAtPosition(arg2);
			Log.e("SaveCard", "Getcard by id="+postCard.getId());
			storageHelper.loadAddressDetails(postCard.getId());
			storageHelper.loadCardsTextDetails(postCard.getId());
			mAppDataHolder.setPostCardDetails(postCard);
			
			Intent intentCreateCard = new Intent(getApplicationContext(), CreateCard.class);
			startActivityForResult(intentCreateCard, Simple3DGallery.CREATE_CARD_REQUEST_CODE);
		}
	};
	
	public boolean handleMessage(Message msg) {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.saved_cards);
		myHandler = new Handler(this);
		mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
		storageHelper = new PostCardStorageHelper(mAppDataHolder, myHandler);

		myDraftCards = storageHelper.getMyPostCards();
		myDraftCardsAdapter = new CardsAdapter(this, 0, 0, myDraftCards);
		draftCardsList = (ListView) findViewById(R.id.draftCardsList);
		draftCardsList.setAdapter(myDraftCardsAdapter);
		draftCardsList.setOnItemClickListener(cardListener);
		
		readSent();
		mySavedCardsAdapter = new CardsAdapter(this, 0, 0, mySavedCards);
		savedCardsList = (ListView) findViewById(R.id.savedCardsList);
		savedCardsList.setAdapter(mySavedCardsAdapter);
		setTabHostSavedCards();
	}
	
	public void onResume() {
		super.onResume();
		myDraftCards = storageHelper.getMyPostCards();
		myDraftCardsAdapter.notifyDataSetChanged();
	}
	
	private void readSent() {
		//TODO read cards from webservice
		//mySavedCards = storageHelper.getMyPostCards();
		//mySavedCardsAdapter = new CardsAdapter(this, 0, 0, mySavedCards);
		//mySavedCardsAdapter.notifyDataSetChanged();
	}
	
	/** Set tabs.  */
	private void setTabHostSavedCards() {
		tabhostSavedCards = (TabHost) findViewById(R.id.tabhostSavedCards);
		// use this line when using findViewById on tabHost
		tabhostSavedCards.setup(); 		
		
		final TextView indicator = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabhostSavedCards.getTabWidget(), false);
		indicator.setText("Drafts");
		tabhostSavedCards.addTab(tabhostSavedCards.newTabSpec("Drafts").setIndicator(indicator).setContent(R.id.tab1));
				
		final TextView indicator2 = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabhostSavedCards.getTabWidget(), false);
		indicator2.setText("Sent");
		tabhostSavedCards.addTab(tabhostSavedCards.newTabSpec("Sent").setIndicator(indicator2).setContent(R.id.tab2));

		tabhostSavedCards.setCurrentTab(0);
	}

	/** Adapter for PostCards. */ 
	private class CardsAdapter extends ArrayAdapter<PostCard> {
		public CardsAdapter(Context context, int resource, int textViewResourceId, ArrayList<PostCard> mCards) {
			super(context, resource, textViewResourceId, mCards);
			this.cards = mCards;
		}
		private ArrayList<PostCard> cards;

		@Override
		public int getCount() {
			return cards.size();
		}

		@Override
		public PostCard getItem(int position) {
			return cards.get(position);
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			PostCard card = cards.get(position);
			View myConvertView = convertView;

			if (myConvertView == null) {
				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				myConvertView = inflater.inflate(R.layout.card_item, null);
			}	
			TextView template = (TextView) myConvertView.findViewById(R.id.cardItemTemplate);
			template.setText(card.getTemplateName());
			
			TextView savedOn = (TextView) myConvertView.findViewById(R.id.cardItemSavedOn);
			savedOn.setText(card.getCard_date());
			
			int s = card.getStatus();
			String status = "";
			if(s == PostCard.STATUS_CREATED) status = "Created";
			else if(s == PostCard.STATUS_UPDATED) status = "Updated";
			else if(s == PostCard.STATUS_SENT) status = "Sent|Not payed";
			else if(s == PostCard.STATUS_PAYED) status = "Payed|Not confirmed";
			else if(s == PostCard.STATUS_CONFIRMED) status = "Confirmed";
			TextView txtStatus = (TextView) myConvertView.findViewById(R.id.cardItemStatus);
			txtStatus.setText(status);
			
			Bitmap snapshot = Helper.readImageFromSpecifiedDir(context, card.getSnapshotUri());
			ImageView imagePreview = (ImageView) myConvertView.findViewById(R.id.cardItemImage);
			imagePreview.setImageBitmap(snapshot);
						
			return myConvertView;
		}
		@Override
		public long getItemId(int position) {
			return position;
		}
	}
}

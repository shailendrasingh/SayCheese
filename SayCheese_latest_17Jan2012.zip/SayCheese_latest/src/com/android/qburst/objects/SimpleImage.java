package com.android.qburst.objects;

import android.graphics.Bitmap;

public class SimpleImage {
	
	private String id;
	private String name;
	/* Link to small icon of picture */
	private String picture;
	/* Link to original size picture */
	private String source; 
	private int height;
	private int width;
	private Bitmap thubnail;
	
	public SimpleImage (String mId, String mName, String mPicture, String mSource, 
			int mHeight, int mWidth, Bitmap mThubnail) {
		id = mId;
		name = mName;
		picture = mPicture;
		source = mSource;
		height = mHeight;
		width = mWidth;
		thubnail = mThubnail;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public Bitmap getThubnail() {
		return thubnail;
	}
	public void setThubnail(Bitmap thubnail) {
		this.thubnail = thubnail;
	}
}

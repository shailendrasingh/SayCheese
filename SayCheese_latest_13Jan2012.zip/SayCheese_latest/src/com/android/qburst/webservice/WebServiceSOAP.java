package com.android.qburst.webservice;

import java.util.ArrayList;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.util.Log;

public class WebServiceSOAP {
	
	private static String _namespace;
	private static String _url;	
	
	public WebServiceSOAP(String ns, String url) {
		_namespace = ns;
		_url = url;
	}
	
	public SoapObject execute(ArrayList<Object[]> props, String soapAction, String methodName) {
		SoapObject request = new SoapObject(_namespace, methodName); 		
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		
		if (props!=null){
			try {
				for (Object[] o : props) {
					request.addProperty((String)o[0],o[1]);
				}
			} catch (Exception ex) {
				Log.e("WS","Properties problem: "+ex.getMessage());
			}
		}
		
		envelope.dotNet = true;
		envelope.setOutputSoapObject(request);
		HttpTransportSE androidHttpTransport = new HttpTransportSE(_url);

		try {
			androidHttpTransport.call(soapAction, envelope);
			return (SoapObject) envelope.bodyIn;
			//SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
			//ACTV.setHint("Received :" + resultsRequestSOAP.toString());
		} catch (Exception e) {
			e.printStackTrace();
			Log.e("WS","Properties problem: "+e.getMessage());
			
			return null;
		}
	}

}

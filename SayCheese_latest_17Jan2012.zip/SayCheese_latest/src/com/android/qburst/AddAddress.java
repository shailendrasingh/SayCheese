package com.android.qburst;

import com.android.qburst.objects.AddressDetails;
import com.android.qburst.objects.AddressFromZip;
import com.android.qburst.objects.Interfaces.IZipCodeListener;
import com.android.qburst.webservice.Utils;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.RawContacts.Data;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class AddAddress extends Activity {
	private static final int CONTACT_PICKER_RESULT = 1001; 
	private static final int COUNTRY_REQUEST_CODE = 1002; 
	private static final String DEBUG_TAG = "DialogChooseAddress";
	private static final String EDITED_SENDER_ADDRESS = "senderAddress";
	private static final String EDITED_RECEIVER_ADDRESS = "receiverAddress";
	private EditText etFullName;
	private EditText etAddress1, etAddress2 ,etEmail;
	private EditText etCity;
	private EditText etZipCode;
	private EditText etState;
	private TextView etCountry;
	private Button btnAddAddress, btnFetchPostCode;
	private Button btnAddContactFromContacts;
	private ApplicationDataContainer mAppDataHolder;
	private String editedText;
	private Context context = this;
	
	
	
	private IZipCodeListener zipListener = new IZipCodeListener() {
		
		public void handleExceptionWithNetwok() {
			Toast.makeText(context, "Problem with network\nPlease try again later", Toast.LENGTH_LONG).show();
		}

		public void fillPostCodeData(AddressFromZip address) {
				if(!address.street.equalsIgnoreCase("")) {
					String buildingName = address.buildingName.equalsIgnoreCase("") ? "" : ", " + address.buildingName;
					etAddress1.setText(address.buildingNr + ", " + address.street + buildingName);
					etCity.setText("Singapore");
					etCountry.setText("SINGAPORE");			
				}
		}
	};
	
	private OnClickListener myOnClickListener = new OnClickListener() {		
		public void onClick(View v) {
			if(v == btnFetchPostCode) {
				if(!etZipCode.getText().toString().equalsIgnoreCase("")) {
					new FetchFromZipCode(etZipCode.getText().toString()).execute();
				} else {
					Toast.makeText(context, "Please type zip code", Toast.LENGTH_LONG).show();
				}
			} else if (v == etCountry) {	
				Intent intentCountry = new Intent(context, SelectCountry.class);
			    startActivityForResult(intentCountry, COUNTRY_REQUEST_CODE); 
			} else if (v == btnAddAddress) {
				//TODO add validation for fill all fields
				String name = etFullName.getText().toString();
				String address1 = etAddress1.getText().toString();
				String address2 = etAddress2.getText().toString();
				String city = etCity.getText().toString();
				String code = etZipCode.getText().toString();
				String country = etCountry.getText().toString();
				String email = etEmail.getText().toString();
				AddressDetails tempAddress = null;
				if(name.equalsIgnoreCase("") || address1.equalsIgnoreCase("")
						|| city.equalsIgnoreCase("") || code.equalsIgnoreCase("") || country.equalsIgnoreCase(""))
				{
					AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
					builder.setMessage("Please fill in highlighted fields").setPositiveButton("OK", null).show();
					return;
				} else if(!editedText.equals(EDITED_RECEIVER_ADDRESS)){
						if(email.equals("") || !isValidEmail(email)){
							AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
							builder.setMessage("Please check your email field!").setPositiveButton("OK", null).show();
							return;
						 }
				}
				
				if (editedText.equals(EDITED_SENDER_ADDRESS)) {
					//address.type field values 1 - receiver, 2 - sender
					tempAddress = new AddressDetails(2, name, etState.getText().toString(), address1, address2, 
							city, code, country, email);
					mAppDataHolder.setCardSender(tempAddress);
				} else if (editedText.equals(EDITED_RECEIVER_ADDRESS)) {
					tempAddress = new AddressDetails(1, name, etState.getText().toString(), address1, address2, 
							city, code, country, email);
					mAppDataHolder.setCardRecipient(tempAddress);
				}
				getIntent().putExtra("whichAddress", editedText);
                getIntent().putExtra("Address", tempAddress.toString());
                setResult(RESULT_OK, getIntent());
                finish();
			} else if (v == btnAddContactFromContacts) {
				Intent contactPickerIntent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
			    startActivityForResult(contactPickerIntent, CONTACT_PICKER_RESULT); 
			}
		}	
	};
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.address);

		mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
		editedText = getIntent().getStringExtra("editedText");
		setUpControls();
		fillForm();
		setUpListeners();
	}

	private final boolean isValidEmail(CharSequence target) {
	    try {
	        return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
	    }
	    catch( NullPointerException exception ) {
	        return false;
	    }
	}
	
	private void fillForm() {
		if (editedText.equals(EDITED_SENDER_ADDRESS)) {
			etFullName.setHint("From");
			if (mAppDataHolder.getCardSender() != null && mAppDataHolder.getCardSender().checkIfAllDataIsProvidedForSender()) {
				AddressDetails sender = mAppDataHolder.getCardSender();
				etFullName.setText(sender.getFullName());
				etAddress1.setText(sender.getAddress1());
				etAddress2.setText(sender.getAddress2());
				etCity.setText(sender.getCity());
				etZipCode.setText(sender.getZipCode());
				etState.setText(sender.getState());
				etCountry.setText(sender.getCountry());
				etEmail.setText(sender.getEmail());
			}
		} else if (editedText.equals(EDITED_RECEIVER_ADDRESS)) {
			etFullName.setHint("To");
			if (mAppDataHolder.getCardRecipient() != null && mAppDataHolder.getCardRecipient().checkIfAllDataIsProvidedForRecepient() ) {
				AddressDetails recipient = mAppDataHolder.getCardRecipient();
				etFullName.setText(recipient.getFullName());
				etAddress1.setText(recipient.getAddress1());
				etAddress2.setText(recipient.getAddress2());
				etCity.setText(recipient.getCity());
				etZipCode.setText(recipient.getZipCode());
				etState.setText(recipient.getState());
				etCountry.setText(recipient.getCountry());
				etEmail.setText(recipient.getEmail());
			}
		}		
	}

	private void setUpControls() {
		etFullName = (EditText) findViewById(R.id.et_full_name);
		etAddress1 = (EditText) findViewById(R.id.et_Address1);
		etAddress2 = (EditText) findViewById(R.id.et_Address2);
		etCity = (EditText) findViewById(R.id.et_City);
		etZipCode = (EditText) findViewById(R.id.et_ZipCode);
		etState = (EditText) findViewById(R.id.et_State);		
		etCountry = (TextView) findViewById(R.id.et_Country);
		btnAddAddress = (Button) findViewById(R.id.btn_add_address);
		btnFetchPostCode = (Button) findViewById(R.id.btn_fetch_postCode);
		btnAddContactFromContacts = (Button) findViewById(R.id.btn_select_contact);
		etEmail = (EditText) findViewById(R.id.et_email_address);
		if(editedText.equals(EDITED_RECEIVER_ADDRESS)){
			etEmail.setBackgroundResource(R.drawable.rounded_borders_white);
		}
		
	}

	private void setUpListeners() {
		btnFetchPostCode.setOnClickListener(myOnClickListener);
		etCountry.setOnClickListener(myOnClickListener);
		btnAddAddress.setOnClickListener(myOnClickListener);
		btnAddContactFromContacts.setOnClickListener(myOnClickListener);
	}
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
	    if (resultCode == RESULT_OK) {  
	        switch (requestCode) {  
	        case CONTACT_PICKER_RESULT:  
	            // handle contact results  
	        	resetForm();
	        	fetchContactData(data);
	            break; 
	        case COUNTRY_REQUEST_CODE:  
	        	String country = data.getStringExtra("country");
	        	etCountry.setText(country);
	            break; 
	        }  
	  
	    } else {  
	        // gracefully handle failure  
	        Log.w(DEBUG_TAG, "Warning: activity result not ok");  
	    }  
	}  
	
	private void fetchContactData(Intent data) {
		String email = "";
		Uri result = data.getData();  
		ContentResolver cr = getContentResolver();
		Cursor chosenContact =  cr.query(result, null, null, null, null);
		if (chosenContact.moveToFirst()) {
			String contact_id = chosenContact.getString(chosenContact.getColumnIndex(ContactsContract.Contacts._ID));
			String raw_contact_id = chosenContact.getString(chosenContact.getColumnIndex(ContactsContract.Contacts._ID));
	        String name = chosenContact.getString(chosenContact.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
			chosenContact.close();
			//find email address
			Cursor emailCur = getContentResolver().query( 
		        		ContactsContract.CommonDataKinds.Email.CONTENT_URI,	null,
		        		ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?", 
		        		new String[]{contact_id}, null); 
        	while (emailCur.moveToNext()) { 
        	    email = emailCur.getString(emailCur.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
         	    break;
         	}
        	emailCur.close();
        	
        	Cursor c = getContentResolver().query(ContactsContract.Data.CONTENT_URI,
        	          new String[] {
		        			Data._ID, 
		        			ContactsContract.CommonDataKinds.StructuredPostal.STREET, 
		        			ContactsContract.CommonDataKinds.StructuredPostal.CITY, 
		        			ContactsContract.CommonDataKinds.StructuredPostal.REGION,
		        			ContactsContract.CommonDataKinds.StructuredPostal.POSTCODE,
		        			ContactsContract.CommonDataKinds.StructuredPostal.COUNTRY},
        	          Data.RAW_CONTACT_ID + "=?" + " AND "
        	                  + Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE + "'",
        	          new String[] {String.valueOf(raw_contact_id)}, null);
        	
        	while (c.moveToNext()) {
        		String street = c.getString(1);
        		String city = c.getString(2);
        		String region = c.getString(3);
        		String postcode = c.getString(4);
        		String country = c.getString(5) != null ? c.getString(5) : "";
        		
		 		etAddress1.setText(street != null ? street : "");
				etCity.setText(city != null ? city : "");
				etState.setText(region != null ? region : "");
				etZipCode.setText(postcode != null ? postcode : "");
				
				Resources res = getResources();
				String[] countries = res.getStringArray(R.array.countries_array);
				for(String ctry : countries) {
					if(ctry.equalsIgnoreCase(country)){
						etCountry.setText(ctry);
						break;
					}
				}
				break;
        	}
        	c.close();
    		etFullName.setText(name != null ? name : "");
			etEmail.setText(email);      	
		}
	}	
	
	private void resetForm(){
		etAddress1.setText("");
		etCity.setText("");
		etState.setText("");
		etZipCode.setText("");
		etCountry.setText("");
		etFullName.setText("");
		etEmail.setText("");
	}
	
	private class FetchFromZipCode extends AsyncTask<Void, String, AddressFromZip> implements OnCancelListener {

		ProgressDialog myDialog;
		String zipCode;
		public FetchFromZipCode(String mZipCode) {
			zipCode = mZipCode;
			myDialog = new ProgressDialog(context);
			myDialog.setCancelable(true);
			myDialog.setOnCancelListener(this);
			myDialog.setMessage("Fetching address based on Zip Code...");
		}
		
		@Override
		protected AddressFromZip doInBackground(Void... params) {
			try {
				 return Utils.getAddress(zipCode);
			} catch (Exception e) {
				Log.e("fetchPostCode","" + e.getMessage());
			}
			return null;
		}
		
		@Override
		protected void onPostExecute(AddressFromZip address) {
			myDialog.dismiss();
			if(address == null ) {
				zipListener.handleExceptionWithNetwok();
			} else {
				zipListener.fillPostCodeData(address);
			}
		}
		
		@Override
		protected void onPreExecute() {
			myDialog.show();
			super.onPreExecute();
		}
		
		@Override
		protected void onProgressUpdate(String... values) {
			myDialog.setMessage(values[0]);
		}
		
		public void onCancel(DialogInterface dialog) {
			this.cancel(true);
		}
	}
}

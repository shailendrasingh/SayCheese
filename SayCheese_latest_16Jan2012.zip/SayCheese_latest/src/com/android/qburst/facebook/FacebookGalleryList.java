package com.android.qburst.facebook;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import com.android.qburst.BaseActivity;
import com.android.qburst.R;
import com.android.qburst.facebook.Facebook.DialogListener;
import com.android.qburst.facebook.SessionEvents.AuthListener;
import com.android.qburst.facebook.SessionEvents.LogoutListener;
import com.android.qburst.objects.FacebookGallery;
import com.flurry.android.FlurryAgent;

public class FacebookGalleryList extends BaseActivity {
	private static final String TAG = "FacebookGalleryList";
	private static final int FACEBOOK_GALLERY_GRID_REQUEST = 9576;
    /* Your Facebook Application ID must be set before running this example
     * See http://www.facebook.com/developers/createapp.php
     */
    public static final String APP_ID = "335380463157481";
    public static final String APP_SECRET="b2d88daf780f29f21cf849f52885cf66";
    public static String[] permissions = {"offline_access", "publish_stream", "user_photos", "publish_checkins", "photo_upload", "read_stream"};
    final int AUTHORIZE_ACTIVITY_RESULT_CODE = 0;
    private ListView facebookGalleryList;
    private Handler mHandler;
	FacebookGalleryAdapter fbGalleryListAdapter;
	  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.facebook_gallery_list);
		mHandler = new Handler();
		
        if (APP_ID == null) {
            Util.showAlert(this, "Warning", "Facebook Applicaton ID must be " +
                    "specified before running this example: see FbAPIs.java");
            return;
        }
        
        //Create the Facebook Object using the app id.
       	Utility.mFacebook = new Facebook(APP_ID);
       	//Instantiate the asynrunner object for asynchronous api calls.
       	Utility.mAsyncRunner = new AsyncFacebookRunner(Utility.mFacebook);        
       	//restore session if one exists
        SessionStore.restore(Utility.mFacebook, this);
        SessionEvents.addAuthListener(new FbAPIsAuthListener());
        SessionEvents.addLogoutListener(new FbAPIsLogoutListener());

       	if(Utility.mFacebook.isSessionValid()) {
       		setUpGalleryList();
       	} else {
       		Utility.mFacebook.authorize(this, permissions,Facebook.FORCE_DIALOG_AUTH /*AUTHORIZE_ACTIVITY_RESULT_CODE*/, new LoginDialogListener());
       	}
	}
	
	private void setUpGalleryList(){
		facebookGalleryList = (ListView) findViewById(R.id.facebookGalleryList);
		facebookGalleryList.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				TextView gallName = (TextView) view.findViewById(R.id.itemGalleryName);
				TextView gallId = (TextView) view.findViewById(R.id.itemGalleryId);
				TextView gallCount = (TextView) view.findViewById(R.id.itemGalleryCount);
				Log.i(TAG, " Open Facebook gallery id=" + gallId.getText().toString()
						+ " name=" + gallName.getText().toString() 
						+ " count=" + gallCount.getText().toString());
				getFacebookPhotosFromGallery(gallId.getText().toString(), gallCount.getText().toString());
			}
		});
		fbGalleryListAdapter = new FacebookGalleryAdapter(FacebookGalleryList.this, 
				R.layout.facebook_gallery_item, new ArrayList<FacebookGallery>());
		facebookGalleryList.setAdapter(fbGalleryListAdapter);    	
		getFacebookPhotosGalleryList();
	}
	
    public void getFacebookPhotosGalleryList() {
    	Bundle params = new Bundle();
   		params.putString("fields", "id, name, count, created_time");
		Utility.mAsyncRunner.request("me/albums", params, new GalleryListListener());
    }
    
    /*
     * Callback for fetching current user's gallery list.
     */
	public class GalleryListListener extends BaseRequestListener {
		public void onComplete(final String response, final Object state) {
			mHandler.post(new Runnable() {
				public void run() {
					try {
						JSONArray jsonArray = new JSONObject(response).getJSONArray("data");
						for (int i = 0; i < jsonArray.length(); i++) {
							JSONObject object = jsonArray.getJSONObject(i);
							String gallId = object.getString("id");
							String gallName = object.getString("name");
							String gallCount = "0";
							if (!object.isNull("count")) {
								gallCount = object.getString("count");
							}
							fbGalleryListAdapter.add(new FacebookGallery(gallId, gallName, gallCount, null));
						}
						fbGalleryListAdapter.notifyDataSetChanged();
					} catch (JSONException e) {
						Log.e(TAG, "JSONException: " + e.getMessage());
					}					
				}
			});
		}
	}
	
    public void getFacebookPhotosFromGallery(String galleryId, String galleryCount) {
    	Bundle params = new Bundle();
   		params.putString("fields", "id, from, name, picture, source, height, width, position, images");
		Utility.mAsyncRunner.request(galleryId + "/photos", params, new SimpleGalleryListener(galleryId, galleryCount));
    }
    
    /*
     * Callback for fetching current user's gallery list.
     */
	public class SimpleGalleryListener extends BaseRequestListener {
		private String gallId;
		private String gallCount;
		
		public SimpleGalleryListener(String id, String count){
			gallId = id;
			gallCount = count;
		}
		
		public void onComplete(final String response, final Object state) {
			mHandler.post(new Runnable() {
				public void run() {
					Intent intent = new Intent(FacebookGalleryList.this, FacebookGalleryGridView.class);
					intent.putExtra("gallId", gallId);
					intent.putExtra("gallCount", gallCount);
					intent.putExtra("gallContent", response);
					startActivityForResult(intent, FACEBOOK_GALLERY_GRID_REQUEST);
				}
			});
		}
	}
	
	 public synchronized void onActivityResult(final int requestCode, int resultCode, final Intent data) {
    	if (resultCode == RESULT_OK) {  
	    	switch (requestCode) {
	    		case FACEBOOK_GALLERY_GRID_REQUEST:
					Intent intent = getIntent();
					intent.putExtra("filePath", data.getStringExtra("filePath"));
					intent.putExtra("fileName", data.getStringExtra("fileName"));
					setResult(RESULT_OK, intent);
	                finish();
	                break;
	    		default: 
	    			break;
	    	}
    	 } else {   
 	        Log.w("DialogChoosePicture", "Warning: activity result not ok");  
 	    } 
    }

    /*
     * The Callback for notifying the application when authorization
     *  succeeds or fails.
     */
    
    public class FbAPIsAuthListener implements AuthListener {

        public void onAuthSucceed() {
        	setUpGalleryList();
        }

        public void onAuthFail(String error) {
            //mText.setText("Login Failed: " + error);
        }
    }

    /*
     * The Callback for notifying the application when log out
     *  starts and finishes.
     */
    public class FbAPIsLogoutListener implements LogoutListener {
        public void onLogoutBegin() {
            //mText.setText("Logging out...");
        }

        public void onLogoutFinish() {
            //mText.setText("You have logged out! ");
            //mUserPic.setImageBitmap(null);
        }
    }
    
    private final class LoginDialogListener implements DialogListener {
        public void onComplete(Bundle values) {
            SessionEvents.onLoginSuccess();
        }

        public void onFacebookError(FacebookError error) {
            SessionEvents.onLoginError(error.getMessage());
        }
        
        public void onError(DialogError error) {
            SessionEvents.onLoginError(error.getMessage());
        }

        public void onCancel() {
            SessionEvents.onLoginError("Action Canceled");
        }
    }
}

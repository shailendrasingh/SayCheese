package com.android.qburst.objects;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Spanned;

public class TextDetails {
	
	private Spanned textBody;
	private Typeface font;
	private String fontName;
	private float textSize;
	private float defualtTextSize;
	private int textColor;
	private int position;

	public TextDetails(Spanned mTextBody, String mFontName, 
			float mTextSize, float mDefualtTextSize, int mTextColor, int mPosition, Context myContext){
		textBody = mTextBody;
		fontName = mFontName;
		font = Helper.getFont(mFontName, myContext);
		textSize = mTextSize;
		defualtTextSize = mDefualtTextSize;
		textColor = mTextColor;
		position = mPosition;
	}

	public Spanned getTextBody() {
		return textBody;
	}
	public void setTextBody(Spanned spanned) {
		this.textBody = spanned;
	}
	public Typeface getFont() {
		return font;
	}
	public void setFont(Typeface font) {
		this.font = font;
	}
	public float getTextSize() {
		return textSize;
	}
	public void setTextSize(float textSize) {
		this.textSize = textSize;
	}
	public int getTextColor() {
		return textColor;
	}
	public void setTextColor(int textColor) {
		this.textColor = textColor;
	}

	public String getFontName() {
		return fontName;
	}

	public void setFontName(String fontName) {
		this.fontName = fontName;
	}
	
	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public float getDefualtTextSize() {
		return defualtTextSize;
	}

	public void setDefualtTextSize(float defualtTextSize) {
		this.defualtTextSize = defualtTextSize;
	}
	
	
}

package com.android.qburst.objects;

import java.util.Date;

public class PostCard {
	/* status for post card */
	public final static int STATUS_CREATED = 0;
	public final static int STATUS_UPDATED = 1;
	public final static int STATUS_SENT = 2;
	public final static int STATUS_PAYED = 3;
	public final static int STATUS_CONFIRMED = 4;
	
	private int	id;
	private int status;
	private String paypal_tran_id="";
	private String order_id="";
	private String card_date="";
	private String imageUri="";
	private String templateName="";
	private String last_modified="";
	private String snapshotUri="";
	private float currentScale;
	private float currentX;
	private float currentY;

	public PostCard(int id, int mStatus, String order_id, String paypal_tran_id, String card_date, 
			String mImageUri, String mTemplateUri, String mlast_modified, String mSnapshotUri ,
			float mCurrentScale, float mCurrentX, float mCurrentY) {

		this.id = id;
		this.status = mStatus;
		this.order_id = order_id;
		this.paypal_tran_id = paypal_tran_id;
		this.card_date = card_date;
		this.imageUri = mImageUri;
		this.templateName = mTemplateUri;
		this.last_modified = mlast_modified;
		this.snapshotUri = mSnapshotUri;
		this.currentScale = mCurrentScale;
		this.currentX = mCurrentX;
		this.currentY = mCurrentY;
	}
	
	public PostCard(String mImageUri) {
		this.card_date = new Date().toString();
		this.imageUri = mImageUri;
	}

	public int getStatus() {
		return status;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	
	public String getPaypal_tran_id() {
		return paypal_tran_id;
	}
	
	public void setPaypal_tran_id(String paypal_tran_id) {
		this.paypal_tran_id = paypal_tran_id;
	}
	
	public int getId() {
		return id;
	}
	
	public String getOrder_id() {
		return order_id;
	}
	
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	
	public String getCard_date() {
		return card_date;
	}
	
	public void setCard_date(String card_date) {
		this.card_date = card_date;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getImageUri() {
		return imageUri;
	}

	public void setImageUri(String imageUri) {
		this.imageUri = imageUri;
	}

	public String getLast_modified() {
		return last_modified;
	}

	public void setLast_modified(String last_modified) {
		this.last_modified = last_modified;
	}
	
	public String getSnapshotUri() {
		return snapshotUri;
	}

	public void setSnapshotUri(String snapshotUri) {
		this.snapshotUri = snapshotUri;
	}

	public float getCurrentScale() {
		return currentScale;
	}

	public void setCurrentScale(float currentScale) {
		this.currentScale = currentScale;
	}

	public float getCurrentX() {
		return currentX;
	}

	public void setCurrentX(float currentX) {
		this.currentX = currentX;
	}

	public float getCurrentY() {
		return currentY;
	}

	public void setCurrentY(float currentY) {
		this.currentY = currentY;
	}
}

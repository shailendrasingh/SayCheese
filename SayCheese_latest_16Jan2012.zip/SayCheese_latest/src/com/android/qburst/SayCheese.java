package com.android.qburst;

import java.util.ArrayList;

import com.android.qburst.objects.PostCard;
import com.android.qburst.webservice.Utils;
import com.flurry.android.FlurryAgent;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.Log;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;

public class SayCheese extends TabActivity implements Callback {

	static final int GALLERY_TYPE_ALL = 0;
	static final int GALLERY_TYPE_CNY = 1;
	static final int GALLERY_TYPE_BIRTHDAY = 2;
	static final int GALLERY_TYPE_EASTER = 3;
	static final int GALLERY_TYPE_ANNIVERSARY = 4;
	static final int GALLERY_TYPE_LOVE = 5;
	ArrayList<PostCard> myPostCards=null;
	Handler myHandler;
	
	private OnTabChangeListener templateListener = new OnTabChangeListener() {
		
		public void onTabChanged(String tabId) {
			FlurryAgent.logEvent("Choosen template: "+tabId);
			
		}
	};
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_screen);
        myHandler = new Handler(this);
        setTypeOfChallengeTabHost();
    }
    
	/** Set main tabs.  */
	private void setTypeOfChallengeTabHost() {
		  TabHost tabHost = getTabHost();  // The activity TabHost
	        Intent intent;  // Reusable Intent for each tab

	        intent = new Intent().setClass(this, Simple3DGallery.class);
	        intent.putExtra("galleryType", GALLERY_TYPE_ALL);
	        final TextView indicator = (TextView) getLayoutInflater().inflate(R.layout.tab_left, tabHost.getTabWidget(), false);
			indicator.setText(R.string.tab_host_label_all);
			tabHost.addTab(tabHost.newTabSpec("all").setIndicator(indicator).setContent(intent));

	        intent = new Intent().setClass(this, Simple3DGallery.class);
	        intent.putExtra("galleryType", GALLERY_TYPE_CNY);
	        final TextView indicator2 = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabHost.getTabWidget(), false);
			indicator2.setText(R.string.tab_host_label_cny);
			tabHost.addTab(tabHost.newTabSpec("cny").setIndicator(indicator2).setContent(intent));
	        
	        intent = new Intent().setClass(this, Simple3DGallery.class);
	        intent.putExtra("galleryType", GALLERY_TYPE_BIRTHDAY);
	        final TextView indicator3 = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabHost.getTabWidget(), false);
			indicator3.setText(R.string.tab_host_label_birthday);
			tabHost.addTab(tabHost.newTabSpec("birthday").setIndicator(indicator3).setContent(intent));
	        
	        
	        intent = new Intent().setClass(this, Simple3DGallery.class);
	        intent.putExtra("galleryType", GALLERY_TYPE_EASTER);
	        final TextView indicator4 = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabHost.getTabWidget(), false);
			indicator4.setText(R.string.tab_host_label_easter);
			tabHost.addTab(tabHost.newTabSpec("easter").setIndicator(indicator4).setContent(intent));
	        
	        intent = new Intent().setClass(this, Simple3DGallery.class);
	        intent.putExtra("galleryType", GALLERY_TYPE_ANNIVERSARY);
	        final TextView indicator5 = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabHost.getTabWidget(), false);
			indicator5.setText(R.string.tab_host_label_anniversary);
			tabHost.addTab(tabHost.newTabSpec("anniversary").setIndicator(indicator5).setContent(intent));
	        
	        intent = new Intent().setClass(this, Simple3DGallery.class);
	        intent.putExtra("galleryType", GALLERY_TYPE_LOVE);
	        final TextView indicator6 = (TextView) getLayoutInflater().inflate(R.layout.tab_right, tabHost.getTabWidget(), false);
			indicator6.setText(R.string.tab_host_label_love);
			tabHost.addTab(tabHost.newTabSpec("love").setIndicator(indicator6).setContent(intent));

	        tabHost.setCurrentTab(0);  
	        tabHost.setOnTabChangedListener(templateListener);
	}

	public boolean handleMessage(Message msg) {
		// TODO Auto-generated method stub
		return true;
	}
}
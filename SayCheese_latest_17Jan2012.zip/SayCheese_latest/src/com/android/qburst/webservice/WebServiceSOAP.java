package com.android.qburst.webservice;

import java.util.ArrayList;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;



import android.util.Log;

public class WebServiceSOAP {
	
	private static String _namespace;
	private static String _url;	
	
	public WebServiceSOAP(String ns, String url) {
		_namespace = ns;
		_url = url;
	}
	
	public SoapObject execute(ArrayList<Object[]> props, String soapAction, String methodName) {
		SoapObject request = new SoapObject(_namespace, methodName); 		
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
		
		if (props!=null){
			try {
				for (Object[] o : props) {
					request.addProperty((String)o[0],o[1]);
				}
			} catch (Exception ex) {
				Log.e("WS","Properties problem: "+ex.getMessage());
			}
		}
		
		envelope.dotNet = true;
		envelope.setOutputSoapObject(request);
		HttpTransportSE androidHttpTransport = new HttpTransportSE(_url);

		try {
			androidHttpTransport.call(soapAction, envelope);
			return (SoapObject) envelope.bodyIn;
			//SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
			//ACTV.setHint("Received :" + resultsRequestSOAP.toString());
		} catch (Exception e) {
			e.printStackTrace();
			Log.e("WS","Properties problem: "+e.getMessage());
			
			return null;
		}
	}
	
	
	
	public SoapObject run(String[] props, String soapAction, String methodName){
		 //Initialize soap request + add parameters
        SoapObject request = new SoapObject(_namespace, methodName); 
        
        if (props!=null){
			request.addProperty(props[0],props[1]);
	     	 Log.i("PROP",  props[0]+","+props[1]);
		}
        
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.setOutputSoapObject(request);
     
        // Make the soap call.
		HttpTransportSE androidHttpTransport = new HttpTransportSE(_url);
        try {
        	
        	//this is the actual part that will call the webservice
			androidHttpTransport.call(soapAction, envelope);        
        } catch (Exception e) {
        	e.printStackTrace(); 
        	Log.i("RUN 2",  e.toString());
        }
        
		// Get the SoapResult from the envelope body.		
		SoapObject result = (SoapObject)envelope.bodyIn;
				
		if(result != null){
//			TextView t = (TextView)this.findViewById(R.id.resultbox);
//			t.setText("SOAP response:\n\n" + result.getProperty(0).toString());
			Log.i("RUN",  result.toString());
		}
		
		return (SoapObject) envelope.bodyIn;
	}
}

package com.android.qburst.coverflow;

import com.android.qburst.objects.Helper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Bitmap.Config;
import android.graphics.PorterDuff.Mode;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

public class CoverFlowAdapter extends BaseAdapter {
	
    /** The width. */
    private float mWidth = 336;

    /** The height. */
    private float mHeight = 226;
	
	int mGalleryItemBackground;
	private Context mContext;

	static final int GALLERY_TYPE_ALL = 0;
	static final int GALLERY_TYPE_CNY = 1;
	static final int GALLERY_TYPE_BIRTHDAY = 2;
	static final int GALLERY_TYPE_EASTER = 3;
	static final int GALLERY_TYPE_ANNIVERSARY = 4;
	static final int GALLERY_TYPE_LOVE = 5;
	
	private int mGalleryType = 0;
	
	private String[] mImageIds = null;
	private String[] mImage0Ids = {"cny1", "birthday1", "birthday2", "easter1", "anniversary1", "love1"}; //ALL
	private String[] mImage1Ids = {"cny1"}; //CNY
	private String[] mImage2Ids = {"birthday1", "birthday2"}; // BIRTHDAY
	private String[] mImage3Ids = {"easter1"};//EASTER
	private String[] mImage4Ids = {"anniversary1"};//ANNIVERSARY
	private String[] mImage5Ids = {"love1"};//LOVE

	private ImageView[] mImages;
	
    /**
     * Set width for all pictures.
     * 
     * @param width
     *            picture height
     */
    public synchronized void setWidth(final float width) {
        this.mWidth = width;
    }

    /**
     * Set height for all pictures.
     * 
     * @param height
     *            picture height
     */
    public synchronized void setHeight(final float height) {
        this.mHeight = height;
    }

	public CoverFlowAdapter(Context c) {
		mContext = c;
		mImages = new ImageView[mImageIds.length];
	}
	
	public CoverFlowAdapter(Context c, int galleryType) {
		mContext = c;
		mGalleryType = galleryType;
		switch (mGalleryType) {
			case GALLERY_TYPE_ALL:
				mImageIds = mImage0Ids;
				break;
			case GALLERY_TYPE_CNY:
				mImageIds = mImage1Ids;
				break;
			case GALLERY_TYPE_BIRTHDAY:
				mImageIds = mImage2Ids;
				break;
			case GALLERY_TYPE_EASTER:
				mImageIds = mImage3Ids;
				break;
			case GALLERY_TYPE_ANNIVERSARY:
				mImageIds = mImage4Ids;
				break;
			case GALLERY_TYPE_LOVE:
				mImageIds = mImage5Ids;
				break;
		}
		
		mImages = new ImageView[mImageIds.length];
	}
	
	public CoverFlowAdapter(Context c, float width, float hight) {
		mContext = c;
		this.mHeight = width;
		this.mHeight = hight;
		mImages = new ImageView[mImageIds.length];
	}

	public boolean createReflectedImages() {
		// The gap we want between the reflection and the original image
		final int reflectionGap = 4;

		int index = 0;
		Paint deafaultPaint = new Paint();
		Paint paint = new Paint();
		PorterDuffXfermode mPorterDuffXfermode = new PorterDuffXfermode(Mode.DST_IN);
		CoverFlow.LayoutParams mParam = new CoverFlow.LayoutParams(120, 180);
		for (String imageName : mImageIds) {
			Bitmap originalImage = Helper.readImageFromAssets(mContext, "templatesthumbnails/", imageName);
		    
			int width = originalImage.getWidth();
			int height = originalImage.getHeight();

			// Create a Bitmap with the flip matrix applied to it.
			// We only want the bottom half of the image
			Bitmap reflectionImage = Bitmap.createBitmap(originalImage, 0,
					height / 2, width, height / 2);

			// Create a new bitmap with same width but taller to fit
			// reflection
			Bitmap bitmapWithReflection = Bitmap.createBitmap(width,
					(height + height / 2), Config.ARGB_8888);

			// Create a new Canvas with the bitmap that's big enough for
			// the image plus gap plus reflection
			Canvas canvas = new Canvas(bitmapWithReflection);
			// Draw in the original image
			canvas.drawBitmap(originalImage, 0, 0, null);
			// Draw in the gap
			
			canvas.drawRect(0, height, width, height + reflectionGap, deafaultPaint);
			// Draw in the reflection
			canvas.drawBitmap(reflectionImage, 0, height + reflectionGap, null);

			// Create a shader that is a linear gradient that covers the
			// reflection
			
			LinearGradient shader = new LinearGradient(0,
					originalImage.getHeight(), 0,
					bitmapWithReflection.getHeight() + reflectionGap,
					0x70ffffff, 0x00ffffff, TileMode.CLAMP);
			// Set the paint to use this shader (linear gradient)
			paint.setShader(shader);
			// Set the Transfer mode to be porter duff and destination in
			paint.setXfermode(mPorterDuffXfermode);
			// Draw a rectangle using the paint with our linear gradient
			canvas.drawRect(0, height, width,
					bitmapWithReflection.getHeight() + reflectionGap, paint);

			ImageView imageView = new ImageView(mContext);
			imageView.setImageBitmap(bitmapWithReflection);
			imageView.setLayoutParams(mParam);
			imageView.setScaleType(ScaleType.MATRIX);
			mImages[index++] = imageView;
		}
		return true;
	}

	public int getCount() {
		return mImageIds.length;
	}

	public Object getItem(int position) {
		return position;
	}

	public long getItemId(int position) {
		return position;
	}
	
	public String getItemName(int position) {
		return mImageIds[position];
	}

	public View getView(int position, View convertView, ViewGroup parent) {

		// Use this code if you want to load from resources
		ImageView i = new ImageView(mContext);

		i.setImageBitmap(Helper.readImageFromAssets(mContext, "templatesthumbnails/", mImageIds[position]));
		i.setLayoutParams(new CoverFlow.LayoutParams((int) mWidth, (int) mHeight));
		i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

		// Make sure we set anti-aliasing otherwise we get jaggies
		BitmapDrawable drawable = (BitmapDrawable) i.getDrawable();
		drawable.setAntiAlias(true);
		return i;
	}

	/**
	 * Returns the size (0.0f to 1.0f) of the views depending on the
	 * 'offset' to the center.
	 */
	public float getScale(boolean focused, int offset) {
		/* Formula: 1 / (2 ^ offset) */
		return Math.max(0, 1.0f / (float) Math.pow(2, Math.abs(offset)));
	}

}

package com.android.qburst;

import java.io.IOException;
import java.io.InputStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.qburst.db.PostCardStorageHelper;
import com.android.qburst.objects.AddressDetails;
import com.android.qburst.objects.Helper;
import com.android.qburst.objects.PostCard;
import com.android.qburst.objects.TextDetails;
import com.android.qburst.paypalMECL.PaymentMECL;
import com.android.qburst.textedition.TextEdition;
import com.android.qburst.zoomableimage.ZoomableImageView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.text.Html;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AccelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class CreateCard extends Activity implements Callback {
	
	public static final int EDIT_TEXT_REQUEST_CODE_FRONT_TITLE = 11;
	public static final int EDIT_TEXT_REQUEST_CODE_FRONT_DESC = 12;
	public static final int EDIT_TEXT_REQUEST_CODE_BACK_TEXT = 13;
	public static final int EDIT_ADDRESSS_REQUEST_CODE = 2;
	public static final int MAKE_FOTO_REQUEST_CODE = 3;
	public static final String EDITED_SENDER_ADDRESS = "senderAddress";
	public static final String EDITED_RECEIVER_ADDRESS = "receiverAddress";
	private LinearLayout llFrontView;
	private LinearLayout llBackView;
	private Button btnBackView;
	private Button btnFrontView;
	private Button btnPay;
	private TextView tvFrontTextTitle;
	private TextView tvFrontDescription;
	private TextView tvBackText;
	private TextView tvBackToText;
	private TextView tvBackAddressText;
	private ZoomableImageView mZoomImageView;
	private ApplicationDataContainer mAppDataHolder;
	//Handler for informing use when on ZoomableImageView we made a click.
	private Handler mClickEventHandler = new Handler(this);
	private PostCardStorageHelper storageHelper = null;
	private PostCard card;
	private boolean isSomethingChange = false;
	private int postCardBoxWidth = 0;
	private int postCardBoxHight = 0;
	private int titleTextStartHight = 0;
	private int descTextStartHight = 0;
	private Context context = this;
	private boolean isFirstImage = true;

	OnClickListener frontBackSideListener = new OnClickListener() {
		
		public void onClick(View v) {
			if (!isFirstImage && v == btnFrontView) { 
			 	applyRotation(0, 90);
			 	isFirstImage = !isFirstImage;
		    } else if (isFirstImage && v == btnBackView) {
		    	applyRotation(0, -90);
		    	isFirstImage = !isFirstImage;
		    }
		}
	};
	
	private void applyRotation(float start, float end) {
		// Find the center of image
		final float centerX = llFrontView.getWidth() / 2.0f;
		final float centerY = llFrontView.getHeight() / 2.0f;
		
		// Create a new 3D rotation with the supplied parameter
		// The animation listener is used to trigger the next animation
		final Flip3dAnimation rotation =  new Flip3dAnimation(start, end, centerX, centerY);
		rotation.setDuration(500);
		rotation.setFillAfter(true);
		rotation.setInterpolator(new AccelerateInterpolator());
		rotation.setAnimationListener(rotation.createDisplayNexView(isFirstImage, llFrontView, llBackView));
	
		if (isFirstImage) {
			llFrontView.startAnimation(rotation);
		} else {
			llBackView.startAnimation(rotation);
		}
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_card);
        mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
        card = mAppDataHolder.getPostCardDetails();
		if(card.getTemplateName() != null){				
			readCardDetailFromTeplate(card.getTemplateName());	
		}
 	   	storageHelper = new PostCardStorageHelper(mAppDataHolder, mClickEventHandler);
        
        setUpControls();
        setUpListeners();
    }
    
	@Override
	public void onStart() {		

		tvBackAddressText.setText(R.string.tv_address_dots);
		tvBackToText.setText(R.string.tv_to_dots);
		
		if(mAppDataHolder.getCardRecipient() != null) {
    		AddressDetails recipient = mAppDataHolder.getCardRecipient();
    		if(recipient.getFullName().length() > 0) {
    			tvBackToText.setText(recipient.getFullName());
    			tvBackAddressText.setText(recipient.toString());
    		}
    	}
		
		super.onStart();
	} 
    private void setUpControls(){
    	
    	llFrontView = (LinearLayout) findViewById(R.id.card_front_view);
    	llFrontView.setVisibility(View.VISIBLE);
    	llBackView = (LinearLayout) findViewById(R.id.card_back_view);
    	llBackView.setVisibility(View.GONE);   	
    	btnBackView = (Button) findViewById(R.id.btn_card_view_back);
    	btnPay = (Button) findViewById(R.id.btn_card_pay);
    	btnFrontView = (Button) findViewById(R.id.btn_card_view_front);
        mZoomImageView = (ZoomableImageView) findViewById(R.id.card_front_view_background);
        mZoomImageView.setHandler(mClickEventHandler);

        Bitmap background = null;
        if(card.getImageUri() != null && card.getImageUri().length() > 0){
        	background = Helper.readImageFromSpecifiedDir(this, card.getImageUri());
        } else { 
        	background = Helper.readImageFromAssets(this, "templatesimages/", card.getTemplateName());
        }

        mZoomImageView.setBitmap(background);
                
        if (postCardBoxWidth != 0 && postCardBoxHight != 0) {       
	        try {
	            RelativeLayout rrfrontCardTextBG = (RelativeLayout) findViewById(R.id.front_card_text_bg);
	            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(Helper.convertFromDPtoInt(this, 132), RelativeLayout.LayoutParams.WRAP_CONTENT);
	            params.leftMargin = Helper.convertFromDPtoInt(this, postCardBoxWidth);
	            params.topMargin = Helper.convertFromDPtoInt(this, postCardBoxHight);
	            rrfrontCardTextBG.setLayoutParams(params);
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
                
        /** set front title text box.*/
       	TextDetails frontTitleText = mAppDataHolder.getFrontTitleText();
    	tvFrontTextTitle = (TextView) findViewById(R.id.card_front_text_title);
    	tvFrontTextTitle.setText(frontTitleText.getTextBody());
		tvFrontTextTitle.setTypeface(frontTitleText.getFont());
		tvFrontTextTitle.setTextSize(frontTitleText.getTextSize());
		tvFrontTextTitle.setTextColor(frontTitleText.getTextColor());
        if (titleTextStartHight != 0) {
        	try {
	            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
	            params.topMargin = Helper.convertFromDPtoInt(this, titleTextStartHight);
	            tvFrontTextTitle.setLayoutParams(params);
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
		
		/** set front desc text box.*/
       	TextDetails frontDescText = mAppDataHolder.getFrontDescText();
    	tvFrontDescription = (TextView) findViewById(R.id.card_front_text_desc);
    	tvFrontDescription.setText(frontDescText.getTextBody());
    	tvFrontDescription.setTypeface(frontDescText.getFont());
    	tvFrontDescription.setTextSize(frontDescText.getTextSize());
    	tvFrontDescription.setTextColor(frontDescText.getTextColor());
        if (descTextStartHight != 0) {
        	try {
	            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.FILL_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
	            params.topMargin = Helper.convertFromDPtoInt(this, descTextStartHight);
	            tvFrontDescription.setLayoutParams(params);
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
		
		/** set back title text box.*/
       	TextDetails backTitleText = mAppDataHolder.getBackText();
       	tvBackText = (TextView) findViewById(R.id.card_back_text);
       	tvBackText.setText(backTitleText.getTextBody());
       	tvBackText.setTypeface(backTitleText.getFont());
       	tvBackText.setTextSize(backTitleText.getTextSize());
       	tvBackText.setTextColor(backTitleText.getTextColor());	
	    	
       	tvBackToText = (TextView) findViewById(R.id.card_back_to_text);
    	tvBackAddressText = (TextView) findViewById(R.id.card_back_address_text);

    }
    //HandlerMessage for informing us when on ZoomableImageView we made a click.
	public boolean handleMessage(Message msg) {
		if(llFrontView.getVisibility() != View.VISIBLE) return true;	
		Intent makeFoto = new Intent(getApplicationContext(), DialogChoosePicture.class);
		startActivityForResult(makeFoto, MAKE_FOTO_REQUEST_CODE);
		return true;
	}
    
    private void setUpListeners(){
    	    
        btnBackView.setOnClickListener(frontBackSideListener);
        btnFrontView.setOnClickListener(frontBackSideListener);
        
        tvFrontTextTitle.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				if(llFrontView.getVisibility() != View.VISIBLE) return;	
				Intent edittext = new Intent(getApplicationContext(), TextEdition.class);
				edittext.putExtra("which", EDIT_TEXT_REQUEST_CODE_FRONT_TITLE);
				startActivityForResult(edittext, EDIT_TEXT_REQUEST_CODE_FRONT_TITLE);
			}
		});
        
        tvFrontDescription.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				if(llFrontView.getVisibility() != View.VISIBLE) return;	
				Intent edittext = new Intent(getApplicationContext(), TextEdition.class);
				edittext.putExtra("which", EDIT_TEXT_REQUEST_CODE_FRONT_DESC);
				startActivityForResult(edittext, EDIT_TEXT_REQUEST_CODE_FRONT_DESC);
			}
		});
        
        tvBackText.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				if(llBackView.getVisibility() != View.VISIBLE) return;	
				Intent edittext = new Intent(getApplicationContext(), TextEdition.class);
				edittext.putExtra("which", EDIT_TEXT_REQUEST_CODE_BACK_TEXT);
				startActivityForResult(edittext, EDIT_TEXT_REQUEST_CODE_BACK_TEXT);
			}
		});
        
        OnClickListener adresDetailListener = new OnClickListener() {
			
			public void onClick(View v) {
				if(llBackView.getVisibility() != View.VISIBLE) return;	
				Intent editAddress = new Intent(getApplicationContext(), AddAddress.class);
				editAddress.putExtra("editedText", EDITED_RECEIVER_ADDRESS);
				startActivityForResult(editAddress, EDIT_ADDRESSS_REQUEST_CODE);
			}
		};
        
		tvBackToText.setOnClickListener(adresDetailListener);
		tvBackAddressText.setOnClickListener(adresDetailListener);
    	btnPay.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				Intent payment = new Intent(getApplicationContext(), PaymentMECL.class);
				startActivity(payment);
			}
		});
    }
    private void setTextDetails(TextView givenTextView, TextDetails details) {
    	givenTextView.setText(details.getTextBody());
       	if(givenTextView == tvFrontTextTitle) {
    		givenTextView.setText(Html.fromHtml("<b>"+details.getTextBody()+"</b>"));
    	}
    	givenTextView.setTextColor(details.getTextColor());
    	givenTextView.setTextSize(details.getTextSize());
    	givenTextView.setTypeface(details.getFont());
    }
    
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
	    if (resultCode == RESULT_OK) {  
	    	TextDetails details;
	        switch (requestCode) {  
	        case EDIT_TEXT_REQUEST_CODE_FRONT_TITLE: 
	        	details = mAppDataHolder.getFrontTitleText();
	        	setTextDetails(tvFrontTextTitle, details);
	        	isSomethingChange = true;
	            break;
	        case EDIT_TEXT_REQUEST_CODE_FRONT_DESC:
	        	details = mAppDataHolder.getFrontDescText();
	        	setTextDetails(tvFrontDescription, details);
	        	isSomethingChange = true;
	            break;
	        case EDIT_TEXT_REQUEST_CODE_BACK_TEXT:  
	        	details = mAppDataHolder.getBackText();
	        	setTextDetails(tvBackText, details);
	        	isSomethingChange = true;
	            break;
	        case EDIT_ADDRESSS_REQUEST_CODE:  
	        	if (mAppDataHolder.getCardRecipient() != null) {
	        		AddressDetails recipient =  mAppDataHolder.getCardRecipient();
	        		tvBackToText.setText(recipient.getFullName());        	
		        	tvBackAddressText.setText(recipient.toString());
		        	isSomethingChange = true;
	        	}
	            break;  
	        case MAKE_FOTO_REQUEST_CODE:
	        	if (mAppDataHolder.getCardFrontImage() != null) {
	        		mZoomImageView.setBitmap(mAppDataHolder.getCardFrontImage());
	        		isSomethingChange = true;
	        	}
	        default:
	        	break;
	        }  
	  
	    } else {   
	        Log.w("CreateCard", "Warning: activity result not ok");  
	    }  
	}
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    //Handle the back button
 	    if(keyCode == KeyEvent.KEYCODE_BACK) {
 	    	if(isSomethingChange){
		    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
		    	builder.setMessage(getText(R.string.ad_question_save_postcard))
		    	       .setCancelable(false)
		    	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
		    	           public void onClick(DialogInterface dialog, int id) {   	 
		    	        	   Log.e("CreateCard", "saving card by id="+card.getId());
		    	        	   Bitmap snapshot = Helper.createSnapShot(findViewById(R.id.card_front_view));
		    	       		   card.setSnapshotUri(Helper.saveImageInExternalCacheDir(context, snapshot, "snapshot"));

		    	       		   if(card.getId() == -1) {
		    	        		   //new card
		    	        		   saveDraft();
			        		   } else { 
			        			   //card taken from draft
			        			   updateDraft(); 
		        			   }   
		    	           }
		    	       })
		    	       .setNegativeButton("No", new DialogInterface.OnClickListener() {
		    	           public void onClick(DialogInterface dialog, int id) {
		    	        	    dialog.cancel();
		    	                finish();
		    	           }
		    	       });
		    	AlertDialog alert = builder.create();
		    	alert.show(); 
 	    	} else {
 	 	    	finish();
 	    	}
 	        mAppDataHolder.makeFreshPostcard();
 	    	return true;
	    }
	    else {
	        return super.onKeyDown(keyCode, event);
	    }

	}
	private void saveDraft(){

		 card = storageHelper.saveCard(card.getOrder_id(),card.getPaypal_tran_id(), card.getImageUri(), 
				 card.getTemplateName(), card.getCard_date(), card.getSnapshotUri(), 
				 mZoomImageView.getCurrentScale(), mZoomImageView.getCurX(), mZoomImageView.getCurY());

         TextDetails frTitT = mAppDataHolder.getFrontTitleText();
         storageHelper.saveTextDetails(card.getId(), frTitT.getPosition(), 
      		   "<b>"+frTitT.getTextBody()+"</b>", frTitT.getFontName(), frTitT.getTextSize(), 
      		   frTitT.getDefualtTextSize(), frTitT.getTextColor());
         TextDetails frDescT = mAppDataHolder.getFrontDescText();
         storageHelper.saveTextDetails(card.getId(), frDescT.getPosition(), 
      		   frDescT.getTextBody().toString(), frDescT.getFontName(), frDescT.getTextSize(), 
      		   frTitT.getDefualtTextSize(),frDescT.getTextColor());
         TextDetails bcText = mAppDataHolder.getBackText();
         storageHelper.saveTextDetails(card.getId(), bcText.getPosition(), 
        		 bcText.getTextBody().toString(), bcText.getFontName(), bcText.getTextSize(), 
      		   frTitT.getDefualtTextSize(),bcText.getTextColor());
         
         AddressDetails mCardRecipient = mAppDataHolder.getCardRecipient();
	  	 if(mCardRecipient == null ) {
	  		 mCardRecipient = new AddressDetails(1);
	  	 }	    	              
	  	 
	  	 int card_id = card.getId();
         storageHelper.saveAddressDetails(card_id, mCardRecipient.getType(), 
      		   mCardRecipient.getFullName(), mCardRecipient.getState(),
      		   mCardRecipient.getAddress1(), mCardRecipient.getAddress2(), mCardRecipient.getCity(), 
      		   mCardRecipient.getZipCode(), mCardRecipient.getCountry(), mCardRecipient.getEmail());
         
         AddressDetails mCardSender = mAppDataHolder.getCardSender();
         
         if(mCardSender == null ) {
        	 mCardSender = new AddressDetails(2);
	  	 }	
         
         storageHelper.saveAddressDetails(card_id, mCardSender.getType(),   mCardSender.getFullName(), 
        		 mCardSender.getState(), mCardSender.getAddress1(), mCardSender.getAddress2(), 
        		 mCardSender.getCity(), mCardSender.getZipCode(), mCardSender.getCountry(), mCardSender.getEmail());
		finish();
	}
	

	private void updateDraft() {
		storageHelper.updateCard(card.getId(), card.getImageUri(), card.getSnapshotUri(),
				mZoomImageView.getCurrentScale(), mZoomImageView.getCurX(), mZoomImageView.getCurY());

         TextDetails frTitT = mAppDataHolder.getFrontTitleText();
         storageHelper.updateTextDetails(card.getId(), frTitT.getPosition(), 
      		   "<b>"+frTitT.getTextBody()+"</b>", frTitT.getFontName(), frTitT.getTextSize(), 
      		   frTitT.getTextColor());
         TextDetails frDescT = mAppDataHolder.getFrontDescText();
         storageHelper.updateTextDetails(card.getId(), frDescT.getPosition(), 
      		   frDescT.getTextBody().toString(), frDescT.getFontName(), frDescT.getTextSize(), 
      		   frDescT.getTextColor());
         TextDetails bcText = mAppDataHolder.getBackText();
         storageHelper.updateTextDetails(card.getId(), bcText.getPosition(), 
        		bcText.getTextBody().toString(), bcText.getFontName(), bcText.getTextSize(), 
        		bcText.getTextColor());
         
         AddressDetails mCardRecipient = mAppDataHolder.getCardRecipient();
	  	   if(mCardRecipient == null ) {
	  		   mCardRecipient = new AddressDetails(1);
	  	   }	    	              
         storageHelper.updateAddressDetails(card.getId(), mCardRecipient.getType(), 
      		   mCardRecipient.getFullName(), mCardRecipient.getState(),
      		   mCardRecipient.getAddress1(), mCardRecipient.getAddress2(),  mCardRecipient.getCity(), 
      		   mCardRecipient.getZipCode(), mCardRecipient.getCountry(), mCardRecipient.getEmail());
         AddressDetails mCardSender = mAppDataHolder.getCardSender();
         storageHelper.updateAddressDetails(card.getId(), mCardSender.getType(), 
      		   mCardSender.getFullName(), mCardSender.getState(),
      		   mCardSender.getAddress1(), mCardSender.getAddress2(),  mCardSender.getCity(),
      		   mCardSender.getZipCode(), mCardSender.getCountry(), mCardSender.getEmail());
         
         CreateCard.this.finish();	
	}
	
	private void readCardDetailFromTeplate(String template){
		try {
			InputStream is = this.getAssets().open("templates/" + template + ".json");
			String jString = Helper.readInputStreamAsString(is);
			
			try {
				JSONObject jObject = new JSONObject(jString); 
				JSONArray viewsObject = jObject.getJSONArray("views");
				for (int i = 0; i < viewsObject.length(); i++) {
					JSONObject object = viewsObject.getJSONObject(i);
					String objectProperties = object.getString("properties");
					JSONObject jobjectProperties = new JSONObject(objectProperties);
					String objectType = object.getString("type");
					String objectViewAttributes = object.getString("view_attributes");
					JSONObject jobjectViewAttributes = new JSONObject(objectViewAttributes);
					String imageXY = jobjectViewAttributes.getString("frame");
					JSONArray arr = new JSONArray(imageXY.replace('{', '[').replace('}', ']'));
					JSONArray arrFirst = new JSONArray(arr.getString(0).replace('{', '[').replace('}', ']'));

					
					if (objectType.equals("SCBackgroundView") && i == 2) {
						//String properyImge = jobjectProperties.getString("image");
						postCardBoxWidth = arrFirst.getInt(0);
						postCardBoxHight = arrFirst.getInt(1);
					}
					
					if (objectType.equals("SCTextView") && i == 3) {
						String textfontColor = jobjectProperties.getString("fontColor");
						JSONArray arrayColor = new JSONArray(textfontColor.replace('{', '[').replace('}', ']'));
						int colAlfa = (int) (arrayColor.getDouble(3)*255);
						int colR = (int) (arrayColor.getDouble(0)*255);
						int colG = (int) (arrayColor.getDouble(1)*255);
						int colB = (int) (arrayColor.getDouble(2)*255);
						String textfontName = jobjectProperties.getString("fontName");
						String textSize = jobjectProperties.getString("size");
						String defaultTextSize = jobjectProperties.getString("default_size");
						String texttext = jobjectProperties.getString("text");
						
						//Read default card details only when we first open template
						if(card.getId() == -1) {
							mAppDataHolder.setFrontTitleText(new TextDetails(Html.fromHtml(texttext),
								textfontName, (new Integer(textSize)).intValue(), 
								(new Integer(defaultTextSize)).intValue(),
								Color.argb(colAlfa, colR, colG, colB), 1, this));
						}
						titleTextStartHight = arrFirst.getInt(1) - postCardBoxHight - 2;
						
					}
					
					if (objectType.equals("SCTextView") && i == 4) {
						String textfontColor = jobjectProperties.getString("fontColor");
						JSONArray arrayColor = new JSONArray(textfontColor.replace('{', '[').replace('}', ']'));
						int colAlfa = (int) (arrayColor.getDouble(3)*255);
						int colR = (int) (arrayColor.getDouble(0)*255);
						int colG = (int) (arrayColor.getDouble(1)*255);
						int colB = (int) (arrayColor.getDouble(2)*255);
						String textfontName = jobjectProperties.getString("fontName");
						String textsize = jobjectProperties.getString("size");
						String defaultTextSize = jobjectProperties.getString("default_size");
						String texttext = jobjectProperties.getString("text");
						
						//Read default card details only when we first open template
						if(card.getId() == -1) {
							mAppDataHolder.setFrontDescText(new TextDetails(Html.fromHtml(texttext),
								textfontName, (new Integer(textsize)).intValue(), 
								(new Integer(defaultTextSize)).intValue(),
								Color.argb(colAlfa, colR, colG, colB), 2, this));
						}
						descTextStartHight = arrFirst.getInt(1) - postCardBoxHight - 2;
					}
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

package com.android.qburst.objects;

public class AddressFromZip {
	public String buildingNr;
	public String buildingName;
	public String street;
	
	public AddressFromZip(String buildingNr, String buildingName, String street) {
		this.buildingNr = buildingNr;
		this.buildingName = buildingName;
		this.street = street;
	}
}
package com.android.qburst.facebook;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;

import com.android.qburst.R;
import com.android.qburst.objects.SimpleImage;

public class FacebookGalleryGridView extends Activity {
	private static final String TAG = "FacebookGalleryGridView";
	public static final int UPDATE_PROGRESS = 1;
	public static final int END_PROGRESS = 0;
	ProgressDialog progressDialog;
	ProgressThread progressThread;
	GridImageAdapter imageListAdapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gallery_grid_view);
		GridView imageGrid = (GridView) findViewById(R.id.PhoneImageGrid);
		TextView tvNoData = (TextView) findViewById(R.id.noImageInGallery);
		String count = getIntent().getStringExtra("gallCount");
		int gallCount = 0;
		try {
			gallCount = (new Integer(count)).intValue();
		} catch (NumberFormatException ne) {
			Log.e(TAG, "NumberFormatException: " + ne.getMessage());
		}
		
		if(gallCount == 0){
			imageGrid.setVisibility(View.GONE);
			tvNoData.setVisibility(View.VISIBLE);
		} else {
			String gallContent = getIntent().getStringExtra("gallContent");
			initGalleryPictureList(gallContent);
			
			imageGrid.setVisibility(View.VISIBLE);
			tvNoData.setVisibility(View.GONE);
			imageListAdapter = new GridImageAdapter(getApplicationContext(), 0, new ArrayList<SimpleImage>());			
			imageGrid.setAdapter(imageListAdapter);
			imageGrid.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView parent, View v, int position, long id) {
					SimpleImage image = (SimpleImage) parent.getItemAtPosition(position);
					//if(image.getWidth() > 336 && image.getHeight() > 226){
					if(image.getWidth() > 100 && image.getHeight() > 100){
						Intent intent = getIntent();						
						intent.putExtra("filePath", image.getSource());
						intent.putExtra("fileName", image.getName());
						setResult(RESULT_OK, intent);
		                finish();
					} else {
						Toast toast = Toast.makeText(getApplicationContext(), 
								getText(R.string.image_to_small_for_postcard) + " (" + image.getWidth() +"x" + image.getHeight() +")",
								Toast.LENGTH_SHORT);
						toast.setGravity(Gravity.CENTER, 0, 0);
						toast.show();						
					}
				}
					
			});
		}
	}
	
	private void initGalleryPictureList(String mGallContent){
		try {	
			JSONArray jsonArray = new JSONObject(mGallContent).getJSONArray("data");
			createProgressDialog(jsonArray);
		} catch (JSONException e) {
			Log.e(TAG, "JSONException: " + e.getMessage());
		}
	}
	
	public class GridImageAdapter extends ArrayAdapter<SimpleImage> {
        private Context mContext;
        private List<SimpleImage> mImageList = new ArrayList<SimpleImage>();
        public GridImageAdapter(Context c, int layoutResourceId, ArrayList<SimpleImage> imageList) {
        	super(c, layoutResourceId, imageList);
            mContext = c;
            mImageList = imageList;
        }
        public View getView(int position, View convertView, ViewGroup parent) {
              System.gc();
              ImageView myView= (ImageView) convertView;
              if (myView==null){
            	  myView = new ImageView(mContext.getApplicationContext());
              }
            SimpleImage image = mImageList.get(position);
            myView.setImageBitmap(image.getThubnail());
            myView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            myView.setPadding(8, 8, 8, 8);
            myView.setLayoutParams(new GridView.LayoutParams(85, 85));
            return myView;
        }
	}	
	 
    protected void createProgressDialog(JSONArray jsonArray) {
        progressDialog = new ProgressDialog(FacebookGalleryGridView.this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setMessage("Downloading photos from Facebook...");
        progressDialog.setCancelable(false);
        progressDialog.setProgress(0);
        progressDialog.show();
        progressThread = new ProgressThread(handler, jsonArray);
        progressThread.start();
    }

	// Define the Handler that receives messages from the thread and update the progress
    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
        	if (FacebookGalleryGridView.END_PROGRESS == msg.what) {
        		progressDialog.dismiss();
            	imageListAdapter.notifyDataSetChanged();
        	} else {
        		int total = msg.arg1;
                progressDialog.setProgress(total);
                SimpleImage listItem = (SimpleImage) msg.obj; 
    			imageListAdapter.add(listItem); 
        	}
        }
    };

    /** Nested class that performs progress calculations (counting) */
    private class ProgressThread extends Thread {
        Handler mHandler;
        JSONArray mJsonArray;
       
        ProgressThread(Handler h, JSONArray jsonArray) {
            mHandler = h;
            mJsonArray = jsonArray;
        }

        public void run() {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Log.e("ERROR", "Thread Interrupted");
            }
            try {	
            	Bitmap localBitmap;
    			for (int i = 0; i < mJsonArray.length(); i++) {
    				//id, from, name, picture, source, height, width, position, images
    				JSONObject object = mJsonArray.getJSONObject(i);
    				String picId = object.getString("id");
    				String picName = " - No name - ";   				
    				if(!object.isNull("name")){
        				picName = object.getString("name");	
    				}		
    				String picPicture = object.getString("picture");
    				String picSource = object.getString("source");
    				String picHeight = object.getString("height");
    				String picWidth = object.getString("width");
    				int picHeightInt = 0;
    				int picWidthInt = 0;
    				try {
    					picHeightInt = (new Integer(picHeight)).intValue();
    					picWidthInt = (new Integer(picWidth)).intValue();
    				} catch (NumberFormatException ne) {
    					Log.e(TAG, "NumberFormatException: " + ne.getMessage());
    				}
    				Log.e("Task loading photo", "picture param="+picId+" "+picName+" "+picPicture+" "+picSource+" "+picHeightInt+" "+picWidthInt);
    				localBitmap = Utility.getBitmap(picPicture);
    				SimpleImage simpleImage = new SimpleImage(picId, picName, picPicture, picSource, picHeightInt, picWidthInt, localBitmap);  				
                    Message msg = new Message();
                    msg.what = FacebookGalleryGridView.UPDATE_PROGRESS;
                    msg.arg1 = Math.round((i*100)/mJsonArray.length());
                    msg.obj = simpleImage;
                    mHandler.sendMessage(msg);
                
    			}
    		} catch (JSONException e) {
    			Log.e(TAG, "JSONException: " + e.getMessage());
    		} 
			Message msg = mHandler.obtainMessage();
			msg.what = FacebookGalleryGridView.END_PROGRESS;
			mHandler.sendMessage(msg);
        }
    }
}

package com.android.qburst.textedition;

import com.android.qburst.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class ChooseSize extends Activity {
	
	private SeekBar seekBarFontSize;
	private EditText txtPreview;
	private float entrySize;
	private float defaultSize;
	private float eventualSize;
	private Button btnSizeDone, btnDefaultSize;
	private OnSeekBarChangeListener fontSizeListener = new OnSeekBarChangeListener() {
		
		
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			
		}
		
		
		public void onStartTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			
		}
		
		
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			eventualSize = progress;
			txtPreview.setTextSize(eventualSize);
			
		}
	};
	private OnClickListener btnListener = new OnClickListener() {

		
		public void onClick(View v) {
			if(v == btnSizeDone) {
				Intent fontSizeIntent = new Intent();
				fontSizeIntent.putExtra("size", eventualSize);
				setResult(RESULT_OK, fontSizeIntent);
				finish();
			} else if(v == btnDefaultSize) {
				eventualSize = defaultSize;
				seekBarFontSize.setProgress((int) eventualSize);
				txtPreview.setTextSize(eventualSize);
			}
		}
		
	};
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editingtext_size);
        findControls();
        setListeners();
    }


	private void findControls() {
		seekBarFontSize = (SeekBar) findViewById(R.id.seekBarFontSize);
		txtPreview = (EditText) findViewById(R.id.etSizeResultingText);
		entrySize = getIntent().getFloatExtra("size", 20);
		defaultSize = getIntent().getFloatExtra("defaultsize", 18);
		entrySize = entrySize >= seekBarFontSize.getMax() ? seekBarFontSize.getMax() : entrySize;
		seekBarFontSize.setProgress((int) entrySize);
		txtPreview.setTextSize(entrySize);
		btnSizeDone = (Button) findViewById(R.id.btnSizeDone);
		btnDefaultSize = (Button) findViewById(R.id.btnDefaultSize);
	}
	
	private void setListeners() {
		seekBarFontSize.setOnSeekBarChangeListener(fontSizeListener);
		btnSizeDone.setOnClickListener(btnListener);
		btnDefaultSize.setOnClickListener(btnListener);
	}
}
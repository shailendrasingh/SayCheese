package com.android.qburst.paypalMECL;


import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Handler.Callback;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import com.android.qburst.ApplicationDataContainer;
import com.android.qburst.R;
import com.android.qburst.db.PostCardStorageHelper;
import com.android.qburst.objects.AddressDetails;
import com.android.qburst.objects.Helper;
import com.android.qburst.objects.PostCard;
import com.android.qburst.objects.TextDetails;
import com.android.qburst.webservice.Utils;
import com.paypal.android.MECL.PayPal;

public class PaymentWebPage extends Activity implements Callback, OnClickListener{

	//The reference token that we get from initializing the MECL library
	public static String _deviceReferenceToken;
	
	// The PayPal server to be used - can also be ENV_NONE and ENV_LIVE
	private static final int server = PayPal.ENV_SANDBOX;
	// The ID of your application that you received from PayPal
	private static final String appID = "APP-80W284485P519543T";
	
	public static final String build = "11.01.04.8174";
	
	//The possible results from initializing MECL
	protected static final int INITIALIZE_SUCCESS = 0;
	protected static final int INITIALIZE_FAILURE = 1;
	
	private Context context = this;
	final Activity activity = this;
	
	//The WebView that we'll use to display MECL
	private WebView webWievPayPal;
	private ApplicationDataContainer mAppDataHolder;
	private Handler mClickEventHandler = new Handler(this);
	private PostCardStorageHelper storageHelper = null;
	AddressDetails recipient, sender;
	String deviceId;
	private Button back, forward;

	public void onClick(View v){
		if (v == back){
			webWievPayPal.goBack();
		} else if ( v == forward) {
			webWievPayPal.goForward();
		}
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Let's display the progress in the activity title bar, like the browser app does.
		getWindow().requestFeature(Window.FEATURE_PROGRESS);
		setContentView(R.layout.payment_webpage);
		mAppDataHolder = (ApplicationDataContainer) getApplicationContext();
		storageHelper = new PostCardStorageHelper(mAppDataHolder, mClickEventHandler);
		recipient = mAppDataHolder.getCardRecipient();
		sender = mAppDataHolder.getCardSender();
		TelephonyManager manager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
		deviceId = (manager.getDeviceId() == null ? "" : manager.getDeviceId());
	    webWievPayPal = (WebView) findViewById(R.id.webViewPayment);
	   // webWievPayPal.setBackgroundColor(Color.TRANSPARENT);
	    back = (Button) findViewById(R.id.goToPrevPage);
	    back.setOnClickListener(this);
	    forward = (Button) findViewById(R.id.goToNextPage);
	    back.setOnClickListener(this);
	    
		new PayPalLibraryInitialization(this).execute();
	}
	
    public void initDone(int msg) {
		switch(msg){
	    	case INITIALIZE_SUCCESS:
	    		launchWeb();
	            break;
	    	case INITIALIZE_FAILURE:
	    		//Initialization failure, close the dialog, update the page and show a toast
	    		Toast.makeText(context, "Failed to proceed", Toast.LENGTH_SHORT).show();
	    		break;
		}
	}
    
	 private void launchWeb() {
		 PostCard card = mAppDataHolder.getPostCardDetails();
		 webWievPayPal.getSettings().setJavaScriptEnabled(true);
		 webWievPayPal.setWebChromeClient(new WebChromeClient() {
		   public void onProgressChanged(WebView view, int progress) {		   
			   activity.setTitle("Loading...");
               activity.setProgress(progress * 100);
               if(progress == 100)
                   activity.setTitle(R.string.app_name);
		   }
		 });
		 webWievPayPal.setWebViewClient(new WebViewClient() {
		   public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
		     Toast.makeText(activity, "Oh no! " + description, Toast.LENGTH_SHORT).show();
		   }
		   @Override
           public boolean shouldOverrideUrlLoading(WebView view, String url){
			   //TODO send here to webservice info with confirmation
			   if(url.contains("cancel")){
				   showExitDialog();
			   }else{
				   view.loadUrl(url);
			   }
               return true;
           } 
		 });
		 
		 String url = "http://175.41.140.188/pay/payment_new.php?orderId="+card.getOrder_id()
				                                             +"&deviceToken="+_deviceReferenceToken
				                                             +"&country="+mAppDataHolder.getCardRecipient().getCountry();
		 
		 Log.i("CardPayPal", url.replaceAll("&", "\n&"));
		 webWievPayPal.loadUrl(url);
	     webWievPayPal.requestFocus(View.FOCUS_DOWN);
    }
	 
	 public boolean handleMessage(Message msg) {
			return false;
	 }
	 
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	    //Handle the back button
 	    if(keyCode == KeyEvent.KEYCODE_BACK) {
 	    	showExitDialog();
 	    }
 	   return super.onKeyDown(keyCode, event);
	}

	private void showExitDialog(){
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	builder.setMessage("Do you really want to leave payment process ?")
    	       .setCancelable(false)
    	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
    	           public void onClick(DialogInterface dialog, int id) {   	 
    	        	   onBackPressed();
    	           }
    	       })
    	       .setNegativeButton("No", null)
    	       .show();
	}
	
	private JSONObject readCardFromTemplate(PostCard card){
		JSONObject jCard = null;
		try {
			InputStream is = getAssets().open("templates/" + card.getTemplateName() + ".json");
			String jString = Helper.readInputStreamAsString(is);
			
			jCard  = new JSONObject(jString); 
			JSONArray viewsObject = jCard.getJSONArray("views");
			for (int i = 0; i < viewsObject.length(); i++) {
				JSONObject object = viewsObject.getJSONObject(i);
				String objectProperties = object.getString("properties");
				JSONObject jobjectProperties = new JSONObject(objectProperties);
				String objectType = object.getString("type");
				
				if (objectType.equals("SCBackgroundView") && i==2) { //background image
					jobjectProperties.remove("image");
					jobjectProperties.put("image", card.getImageUri());
					viewsObject.put(i,jobjectProperties);
				}
				
				if (objectType.equals("SCTextView") && i==3) { //front title text
					TextDetails frontTitle = mAppDataHolder.getFrontTitleText();
					jobjectProperties.remove("fontColor");
					jobjectProperties.put("fontColor", String.format("{%f, %f, %f, %f}", 
									(float) Color.red(frontTitle.getTextColor()/255),
									(float) Color.green(frontTitle.getTextColor()/255),
									(float) Color.blue(frontTitle.getTextColor()/255),
									(float) Color.alpha(frontTitle.getTextColor()/255)
							));
					jobjectProperties.remove("fontName");
					jobjectProperties.put("fontName", frontTitle.getFontName());
					jobjectProperties.remove("size");
					jobjectProperties.put("size", frontTitle.getTextSize());
					jobjectProperties.remove("text");
					jobjectProperties.put("text", frontTitle.getTextBody());
					viewsObject.put(i,jobjectProperties);
				}
				
				if (objectType.equals("SCTextView") && i==4) { //front desc text
					TextDetails frontDesc = mAppDataHolder.getFrontDescText();
					jobjectProperties.remove("fontColor");
					jobjectProperties.put("fontColor", String.format("{%f, %f, %f, %f}", 
							(float) Color.red(frontDesc.getTextColor()/255),
							(float) Color.green(frontDesc.getTextColor()/255),
							(float) Color.blue(frontDesc.getTextColor()/255),
							(float) Color.alpha(frontDesc.getTextColor()/255)
							));
					jobjectProperties.remove("fontName");
					jobjectProperties.put("fontName", frontDesc.getFontName());
					jobjectProperties.remove("size");
					jobjectProperties.put("size", frontDesc.getTextSize());
					jobjectProperties.remove("text");
					jobjectProperties.put("text", frontDesc.getTextBody());
					viewsObject.put(i,jobjectProperties);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jCard;
	}
	
	private class PayPalLibraryInitialization extends AsyncTask<Void, String, Integer> implements OnCancelListener {

		ProgressDialog myDialog;
		Context pContext;
		
		public PayPalLibraryInitialization(Context mContext) {
			pContext = mContext;
			myDialog = new ProgressDialog(pContext);
			myDialog.setCancelable(true);
			myDialog.setOnCancelListener(this);
		}
		
		@Override
		protected Integer doInBackground(Void... params) {
			PostCard card = mAppDataHolder.getPostCardDetails();
			try {
				
				if(card.getId() == -1){
					publishProgress("Saving card to database...");
					card = storageHelper.saveCard("", "", card.getImageUri(), card.getTemplateName(), 
							Helper.nowDate(), card.getSnapshotUri(), card.getCurrentScale(), 
							card.getCurrentX(), card.getCurrentY());
				}
				
				if(card.getOrder_id().equalsIgnoreCase("")) {
					publishProgress("Sending card to the server...");
				
					String deviceType= " Device: " + android.os.Build.DEVICE
									   + " " + android.os.Build.MODEL + " ("+ android.os.Build.PRODUCT + ")";
					JSONObject jCard =  readCardFromTemplate(card);
					JSONObject response = null;
					InputStream  is = null;
					if(card.getImageUri().length()==0){
						String uri = "templatesimages/"+card.getTemplateName()+".jpg";
						is = getAssets().open(uri);
						card.setImageUri(uri);
						response = Utils.sendCard(card, recipient, sender, deviceId, deviceType, jCard, is);
					}else{
						response = Utils.sendCard(card, recipient, sender, deviceId, deviceType, jCard);
					}
					
					String date = response.getString("createdAt");
					String orderId = response.getString("orderId");
	
					card.setOrder_id(orderId);
					card.setCard_date(date);
					card.setStatus(PostCard.STATUS_SENT);
					storageHelper.addOrderIdAndMarkAsSent(card);
				}
				
				mAppDataHolder.setPostCardDetails(card);

				publishProgress("Loading PayPal...");
				// This is the main initialization call that takes in your Context, the Application ID, the server you would like to connect to, and your PayPalListener
				PayPal.fetchDeviceReferenceTokenWithAppID(pContext, appID, server, new ResultDelegate());
		   			
				// -- These are required settings.
				PayPal.getInstance().setLanguage("en_US"); // Sets the language for the library.
		        // --
				if (PayPal.getInstance().isLibraryInitialized()) {
					return INITIALIZE_SUCCESS;
				}
			}catch (Exception e) {
				e.printStackTrace();
				Log.e("PayPalLibInit","" + e.getMessage());
			}
			return INITIALIZE_FAILURE;
		}
		
		@Override
		protected void onPostExecute(Integer msg) {
			myDialog.dismiss();
			initDone(msg);
		}
		
		@Override
		protected void onPreExecute() {
			myDialog.show();
			super.onPreExecute();
		}
		
		@Override
		protected void onProgressUpdate(String... values) {
			myDialog.setMessage(values[0]);
		}
		
		public void onCancel(DialogInterface dialog) {
			this.cancel(true);
		}
	}
}

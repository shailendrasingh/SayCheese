package com.android.qburst.textedition;

import java.io.IOException;
import java.util.ArrayList;

import com.android.qburst.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ChooseFont extends Activity {
	
	private Context context = this;
	private ListView fontList;
	public ArrayList<FontTypeNamePair> availableFonts = new ArrayList<FontTypeNamePair>(); 
	private OnItemClickListener fontClicked = new OnItemClickListener() {

		
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			Intent itemClicked = new Intent(context, TextEdition.class);
			FontTypeNamePair font = (FontTypeNamePair) arg0.getItemAtPosition(arg2);
			itemClicked.putExtra("font", font.filePath);
			setResult(RESULT_OK, itemClicked);
			finish();
		}
	};
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editingtext_font);
        findControls();
        setFonts();
    }


	private void setFonts() {
		try {
			//3 standard fonts 
			availableFonts.add(new FontTypeNamePair(Typeface.MONOSPACE, "Droid Sans mono", TextEditionConstants.typefaceMono));
			availableFonts.add(new FontTypeNamePair(Typeface.SANS_SERIF, "Droid Sans Serif", TextEditionConstants.typefaceSan));
			availableFonts.add(new FontTypeNamePair(Typeface.SERIF, "Droid Serif", TextEditionConstants.typefaceSerif));
			
			//all other fonts we add to the application (folder assets/fonts)
        	String list[] = getAssets().list("fonts");
        	for(String fileName : list) {
        		availableFonts.add(new FontTypeNamePair(Typeface.createFromAsset(getAssets(), "fonts/" + fileName), fileName.replace(".ttf", ""), fileName.replace(".ttf", "")));
        	}
			
			fontList.setAdapter(new FontsAdapter());
			fontList.setOnItemClickListener(fontClicked);
		} catch (IOException e) {
			Log.i("ChooseFont", e.getMessage());
		}
	}


	private void findControls() {
		fontList = (ListView) findViewById(R.id.etfFontList);

	}
	
	public class FontTypeNamePair {
		public FontTypeNamePair (Typeface type, String name, String filePath){
			this.type = type;
			this.name = name;
			this.filePath = filePath;
		}
		private Typeface type;
		private String name;
		private String filePath;
	}
	
	/** Adapter for fonts. */ 
	private class FontsAdapter extends BaseAdapter {
		
		public int getCount() {
			return availableFonts.size();
		}

		public Object getItem(int position) {
			return availableFonts.get(position);
		}

		public View getView(final int position, View convertView, ViewGroup parent) {
			FontTypeNamePair font = availableFonts.get(position);
			View myConvertView = convertView;

			if (myConvertView == null) {
				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				myConvertView = inflater.inflate(R.layout.font_item, null);
			}	
			TextView fontName = (TextView) myConvertView.findViewById(R.id.etfFontName);
			fontName.setText(font.name);
			fontName.setTypeface(font.type);
						
			return myConvertView;
		}
		
		public long getItemId(int position) {
			return position;
		}
	}
	
}
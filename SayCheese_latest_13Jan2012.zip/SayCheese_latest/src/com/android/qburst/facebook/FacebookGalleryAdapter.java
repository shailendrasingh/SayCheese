package com.android.qburst.facebook;

import java.util.ArrayList;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.android.qburst.R;
import com.android.qburst.objects.FacebookGallery;

public class FacebookGalleryAdapter extends ArrayAdapter<FacebookGallery>  {
	private ArrayList<FacebookGallery> mfbGalleryList;
	private FacebookGalleryList mContext;
	/** Layout for single item. */ 
	private int mLayoutResourceId;
	
	public FacebookGalleryAdapter(FacebookGalleryList context, int layoutResourceId, ArrayList<FacebookGallery> fbGalleryList){
		super(context, layoutResourceId, fbGalleryList);
		mContext = context;
		mfbGalleryList = fbGalleryList;
		mLayoutResourceId = layoutResourceId;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		FacebookGallery simpleGallery = mfbGalleryList.get(position);
		View myConvertView = convertView;

		if (myConvertView == null) {
			LayoutInflater inflater = LayoutInflater.from(mContext.getBaseContext());
			myConvertView = inflater.inflate(mLayoutResourceId, null);
		}	
		TextView name = (TextView) myConvertView.findViewById(R.id.itemGalleryName);
		TextView id = (TextView) myConvertView.findViewById(R.id.itemGalleryId);
		TextView count = (TextView) myConvertView.findViewById(R.id.itemGalleryCount);
		name.setText(simpleGallery.getName());			
		id.setText(simpleGallery.getId());
		count.setText(simpleGallery.getCount());
					
		return myConvertView;
	}
}

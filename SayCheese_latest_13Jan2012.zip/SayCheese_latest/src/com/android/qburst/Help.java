package com.android.qburst;

import java.util.ArrayList;

import com.android.qburst.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class Help extends Activity {

	private Context context = this;
	private ListView helpOptionsList;
	private String About = ""
				+ "Donec at posuere diam. " 
				+ "Vestibulum sit amet magna purus, condimentum mollis velit. " 
				+ "Nullam hendrerit lacus et diam ultricies in rutrum sapien rutrum. " 
				+ "Etiam consequat sem a felis eleifend adipiscing. " 
				+ "Mauris congue, nisl non sagittis vulputate, " 
				+ "augue arcu pellentesque turpis, non interdum sem felis nec dui. " 
				+ "Aliquam erat volutpat. Duis auctor libero et magna suscipit " 
				+ "molestie. ";
	private String Create = ""
			+ "Donec at posuere diam. " 
			+ "Vestibulum sit amet magna purus, condimentum mollis velit. " 
			+ "Nullam hendrerit lacus et diam ultricies in rutrum sapien rutrum. " 
			+ "Etiam consequat sem a felis eleifend adipiscing. " 
			+ "Mauris congue, nisl non sagittis vulputate, " 
			+ "augue arcu pellentesque turpis, non interdum sem felis nec dui. " 
			+ "Aliquam erat volutpat. Duis auctor libero et magna suscipit " 
			+ "molestie. ";
	private String Send = ""
			+ "Donec at posuere diam. " 
			+ "Vestibulum sit amet magna purus, condimentum mollis velit. " 
			+ "Nullam hendrerit lacus et diam ultricies in rutrum sapien rutrum. " 
			+ "Etiam consequat sem a felis eleifend adipiscing. " 
			+ "Mauris congue, nisl non sagittis vulputate, " 
			+ "augue arcu pellentesque turpis, non interdum sem felis nec dui. " 
			+ "Aliquam erat volutpat. Duis auctor libero et magna suscipit " 
			+ "molestie. ";
	private String Order = ""
			+ "Donec at posuere diam. " 
			+ "Vestibulum sit amet magna purus, condimentum mollis velit. " 
			+ "Nullam hendrerit lacus et diam ultricies in rutrum sapien rutrum. " 
			+ "Etiam consequat sem a felis eleifend adipiscing. " 
			+ "Mauris congue, nisl non sagittis vulputate, " 
			+ "augue arcu pellentesque turpis, non interdum sem felis nec dui. " 
			+ "Aliquam erat volutpat. Duis auctor libero et magna suscipit " 
			+ "molestie. ";
	private String Terms = ""
			+ "Donec at posuere diam. " 
			+ "Vestibulum sit amet magna purus, condimentum mollis velit. " 
			+ "Nullam hendrerit lacus et diam ultricies in rutrum sapien rutrum. " 
			+ "Etiam consequat sem a felis eleifend adipiscing. " 
			+ "Mauris congue, nisl non sagittis vulputate, " 
			+ "augue arcu pellentesque turpis, non interdum sem felis nec dui. " 
			+ "Aliquam erat volutpat. Duis auctor libero et magna suscipit " 
			+ "molestie. ";
	private OnItemClickListener helpItemListener = new OnItemClickListener() {

		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			String title = (String) arg0.getItemAtPosition(arg2);
			Intent itemClicked = new Intent(context, HelpOptionText.class);
			itemClicked.putExtra("title", title);
			switch(arg2) {
			case 0: itemClicked.putExtra("body", About);
				break;
			case 1: itemClicked.putExtra("body", Create);
				break;
			case 2: itemClicked.putExtra("body", Send);
				break;
			case 3: itemClicked.putExtra("body", Order);
				break;
			case 4: itemClicked.putExtra("body", Terms);
				break;
			default:
				break;
			}
			startActivity(itemClicked);
		}
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help);
		findControls();
		setListeners();
	}
	private void setListeners() {
		helpOptionsList.setOnItemClickListener(helpItemListener);
	}
	private void findControls() {
		helpOptionsList = (ListView) findViewById(R.id.helpOptionsList);
		helpOptionsList.setAdapter(new HelpAdapter());
	}
	
	/** Adapter for help options. */ 
	private class HelpAdapter extends BaseAdapter {
		private ArrayList<String> helpOptions = new ArrayList<String>();
		
		public HelpAdapter(){
			helpOptions.add("About cards");
			helpOptions.add("Create a card");
			helpOptions.add("Send a card");
			helpOptions.add("Ordering and billing");
			helpOptions.add("Terms and conditions");
		}
		public int getCount() {
			return helpOptions.size();
		}

		public Object getItem(int position) {
			return helpOptions.get(position);
		}

		public View getView(final int position, View convertView, ViewGroup parent) {
			String option = helpOptions.get(position);
			View myConvertView = convertView;

			if (myConvertView == null) {
				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				myConvertView = inflater.inflate(R.layout.help_item, null);
			}	
			TextView title = (TextView) myConvertView.findViewById(R.id.helpItemOptionName);
			title.setText(option);			
						
			return myConvertView;
		}
		
		public long getItemId(int position) {
			return position;
		}
	}

}

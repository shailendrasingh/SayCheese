package com.android.qburst.textedition;

import com.android.qburst.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TabHost.OnTabChangeListener;

public class ChooseColor extends Activity {
	
	private TabHost tabhostColors;
	private int color = Color.argb(255, 0, 0, 0);
	private SeekBar seekBarFontRed, seekBarFontGreen, seekBarFontBlue, seekBarFontAlpha; 
	private TextView txtResultingText;
	private Button btnColorDone;
	int red, green, blue, alpha;
	private OnTabChangeListener tabChangedListener = new OnTabChangeListener() {
		
		
		public void onTabChanged(String tabId) {
			seekBarFontRed.setVisibility(tabId.equalsIgnoreCase(TextEditionConstants.chooseColorRed) ? View.VISIBLE : View.GONE);
			seekBarFontGreen.setVisibility(tabId.equalsIgnoreCase(TextEditionConstants.chooseColorGreen) ? View.VISIBLE : View.GONE);
			seekBarFontBlue.setVisibility(tabId.equalsIgnoreCase(TextEditionConstants.chooseColorBlue) ? View.VISIBLE : View.GONE);
			seekBarFontAlpha.setVisibility(tabId.equalsIgnoreCase(TextEditionConstants.chooseColorAlpha) ? View.VISIBLE : View.GONE);			
		}
	};
	
	private OnSeekBarChangeListener fontColorListener = new OnSeekBarChangeListener() {
		
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			
		}
		
		public void onStartTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			
		}
		
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			color = Color.argb(seekBarFontAlpha.getProgress(), seekBarFontRed.getProgress(), 
					seekBarFontGreen.getProgress(),seekBarFontBlue.getProgress());
			txtResultingText.setTextColor(color);
		}
	};
	private OnClickListener btnColorDoneListener = new OnClickListener() {
		
		public void onClick(View v) {
			Intent fontColorIntent = new Intent();
			fontColorIntent.putExtra("color", color);
			setResult(RESULT_OK, fontColorIntent);
			finish();
			
		}
	};
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editingtext_color);
        findControls();
        setControls();
        setListeners();
        setTabHostColors();
    }


	private void setControls() {
		color = getIntent().getIntExtra("color", 255);
		txtResultingText.setTextSize(40);
		txtResultingText.setTextColor(color);
		red = Color.red(color);
		green = Color.green(color);
		blue = Color.blue(color);
		alpha = Color.alpha(color);
		seekBarFontRed.setProgress(red);
		seekBarFontGreen.setProgress(green);
		seekBarFontBlue.setProgress(blue);
		seekBarFontAlpha.setProgress(alpha);
		
	}


	private void findControls() {
		seekBarFontRed = (SeekBar) findViewById(R.id.seekBarColorRed);
		seekBarFontGreen = (SeekBar) findViewById(R.id.seekBarColorGreen);
		seekBarFontBlue = (SeekBar) findViewById(R.id.seekBarColorBlue);
		seekBarFontAlpha = (SeekBar) findViewById(R.id.seekBarColorAlpha);
		tabhostColors = (TabHost) findViewById(R.id.tabhostColors);
		txtResultingText = (TextView) findViewById(R.id.etColorResultingText);
		btnColorDone = (Button) findViewById(R.id.btnColorDone);

	}
	
	private void setListeners() {
		tabhostColors.setOnTabChangedListener(tabChangedListener);
		seekBarFontRed.setOnSeekBarChangeListener(fontColorListener);
		seekBarFontGreen.setOnSeekBarChangeListener(fontColorListener);
		seekBarFontBlue.setOnSeekBarChangeListener(fontColorListener);
		seekBarFontAlpha.setOnSeekBarChangeListener(fontColorListener);
		btnColorDone.setOnClickListener(btnColorDoneListener);
		
	}
	/** Set tabs.  */
	private void setTabHostColors() {
		
		// use this line when using findViewById on tabHost
		tabhostColors.setup(); 
		
		
		final TextView indicator = (TextView) getLayoutInflater().inflate(R.layout.tab_left, tabhostColors.getTabWidget(), false);
		indicator.setText(TextEditionConstants.chooseColorRed);
		tabhostColors.addTab(tabhostColors.newTabSpec(TextEditionConstants.chooseColorRed).setIndicator(indicator).setContent(R.id.tab1));
		
		final TextView indicator2 = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabhostColors.getTabWidget(), false);
		indicator2.setText(TextEditionConstants.chooseColorGreen);
		tabhostColors.addTab(tabhostColors.newTabSpec(TextEditionConstants.chooseColorGreen).	setIndicator(indicator2).setContent(R.id.tab2));
		
		final TextView indicator3 = (TextView) getLayoutInflater().inflate(R.layout.tab_middle, tabhostColors.getTabWidget(), false);
		indicator3.setText(TextEditionConstants.chooseColorBlue);
		tabhostColors.addTab(tabhostColors.newTabSpec(TextEditionConstants.chooseColorBlue).setIndicator(indicator3).setContent(R.id.tab3));
		
		final TextView indicator4 = (TextView) getLayoutInflater().inflate(R.layout.tab_right, tabhostColors.getTabWidget(), false);
		indicator4.setText(TextEditionConstants.chooseColorAlpha);
		tabhostColors.addTab(tabhostColors.newTabSpec(TextEditionConstants.chooseColorAlpha).setIndicator(indicator4).setContent(R.id.tab4));

		tabhostColors.setCurrentTab(0);

	}
}